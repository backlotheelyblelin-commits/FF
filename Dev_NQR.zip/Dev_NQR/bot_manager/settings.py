"""
Custom setting cho bot con.
Mỗi bot con có setting riêng.
"""
import json
from pathlib import Path

BOTS_DIR = Path(__file__).resolve().parent.parent / "data" / "bots"


DEFAULT_SETTINGS = {
    "bot_name": "My Bot",
    "emoji": "🤖",
    "footer": "",
    "language": "vi",
    "prefix": "/",
    "start_text": "🤖 Bot đã sẵn sàng!\n\nDùng /m để xem lệnh.",
    "help_text": "📖 Gõ /m để xem danh sách lệnh.",
    "delay_default": 1.0,
    "anti_flood": False,
    "auto_delete": True,
    "use_custom_ngon": False,
    "commands": {
        "start": True, "help": True, "mn": True,
        "voice": True, "tag": True, "tag2": True,
        "call": True, "treongon": True, "set": True,
        "off": True, "log": True, "status": True,
    },
}


class BotSettings:
    def __init__(self, acc_id: int):
        self.acc_id = acc_id
        self.dir = BOTS_DIR / f"bot_{acc_id}"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "settings.json"
        self._data = self._load()

    def _load(self) -> dict:
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
                merged = DEFAULT_SETTINGS.copy()
                merged.update(data)
                if "commands" in data:
                    merged["commands"] = {
                        **DEFAULT_SETTINGS["commands"],
                        **data["commands"]
                    }
                return merged
            except Exception:
                pass
        return json.loads(json.dumps(DEFAULT_SETTINGS))

    def save(self):
        self.path.write_text(
            json.dumps(self._data, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

    def get(self, key: str, default=None):
        return self._data.get(key, default)

    def set(self, key: str, value):
        self._data[key] = value
        self.save()

    def all(self) -> dict:
        return self._data.copy()

    # ═══ NGÔN RIÊNG ═══
    def get_ngon_file(self) -> Path:
        return self.dir / "ngon_user.json"

    def load_ngon(self) -> dict:
        f = self.get_ngon_file()
        if f.exists():
            try:
                return json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                pass
        return {"1": {}, "2": {}, "3": {}}

    def save_ngon(self, data: dict):
        self.get_ngon_file().write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )