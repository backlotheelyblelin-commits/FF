"""
Quản lý bot con — hỗ trợ cả 2 loại:
- Bot Token: chạy qua Bot API
- User Session: chạy qua Telethon
"""
import asyncio
from pathlib import Path
from database.db import db

_running_bots: dict[int, asyncio.Task] = {}
BOTS_DIR = Path(__file__).resolve().parent.parent / "data" / "bots"
BOTS_DIR.mkdir(parents=True, exist_ok=True)


async def start_bot(acc_id: int) -> bool:
    """Bật bot con."""
    if acc_id in _running_bots:
        if not _running_bots[acc_id].done():
            return False

    acc = db.get_account(acc_id)
    if not acc:
        return False

    if acc["type"] not in ("bot", "user"):
        return False

    task = asyncio.create_task(_bot_worker(acc_id, acc))
    _running_bots[acc_id] = task
    return True


async def stop_bot(acc_id: int):
    """Dừng bot con."""
    if acc_id in _running_bots:
        task = _running_bots[acc_id]
        if not task.done():
            task.cancel()
        _running_bots.pop(acc_id, None)


async def stop_all():
    """Dừng tất cả."""
    for acc_id in list(_running_bots.keys()):
        await stop_bot(acc_id)


def is_running(acc_id: int) -> bool:
    if acc_id not in _running_bots:
        return False
    return not _running_bots[acc_id].done()


async def auto_start_all_bots():
    """Bật tất cả bot con active (khi bot chủ restart)."""
    for acc in db.get_accounts(status="active"):
        if acc["type"] in ("bot", "user"):
            await start_bot(acc["id"])


# ═══════════════════════════════════════════
# WORKER
# ═══════════════════════════════════════════
async def _bot_worker(acc_id: int, acc: dict):
    """Worker bot con."""
    if acc["type"] == "bot":
        await _run_bot_token(acc_id, acc)
    else:
        await _run_user_session(acc_id, acc)


# ═══════════════════════════════════════════
# BOT TOKEN
# ═══════════════════════════════════════════
async def _run_bot_token(acc_id: int, acc: dict):
    """Chạy bot con qua Bot API."""
    from telegram.ext import (
        ApplicationBuilder, CommandHandler,
        CallbackQueryHandler, MessageHandler, filters
    )

    app = ApplicationBuilder().token(acc["token"]).build()
    app.bot_data["is_botcon"] = True
    app.bot_data["acc_id"] = acc_id

    # Đăng ký handlers
    _register_botcon_handlers(app, acc_id)

    try:
        await app.initialize()
        await app.start()
        await app.updater.start_polling(drop_pending_updates=True)
        while True:
            await asyncio.sleep(3600)
    except asyncio.CancelledError:
        pass
    finally:
        try:
            await app.updater.stop()
            await app.stop()
            await app.shutdown()
        except Exception:
            pass


def _register_botcon_handlers(app, acc_id: int):
    """Đăng ký handlers cho bot con Token."""
    from telegram.ext import CommandHandler, CallbackQueryHandler, MessageHandler, filters

    from handlers.main_menu import start_cmd, main_menu_callback
    from handlers.menu import mn_cmd, help_callback
    from handlers.help_all import help_all_callback
    from handlers.lang import lang_cmd, lang_callback
    from handlers.ping import ping_cmd
    from handlers.bot_config import bot_config_callback, bot_set_input
    from handlers.addngon import (
        addngon_cmd, handle_ngon_file, xemngon_cmd, resetngon_cmd
    )
    from handlers.tag import tag_cmd
    from handlers.tag2 import tag2_cmd
    from handlers.treongon import treongon_cmd
    from handlers.set import set_cmd, setcall_cmd
    from handlers.call import call_cmd
    from handlers.off import off_cmd
    from handlers.im import im_cmd
    from handlers.noi import noi_cmd
    from handlers.cam import cam_cmd
    from handlers.sua import sua_cmd
    from handlers.clear import clear_cmd
    from handlers.status import status_cmd
    from handlers.log import log_cmd
    from handlers.voice import voice_cmd

    # Menu
    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("mn", mn_cmd))
    app.add_handler(CommandHandler("help", mn_cmd))
    app.add_handler(CommandHandler("lang", lang_cmd))
    app.add_handler(CommandHandler("ping", ping_cmd))

    # Spam
    app.add_handler(CommandHandler("tag", tag_cmd))
    app.add_handler(CommandHandler("tag2", tag2_cmd))
    app.add_handler(CommandHandler("treongon", treongon_cmd))
    app.add_handler(CommandHandler("set", set_cmd))
    app.add_handler(CommandHandler("setcall", setcall_cmd))
    app.add_handler(CommandHandler("call", call_cmd))
    app.add_handler(CommandHandler("off", off_cmd))

    # Mod
    app.add_handler(CommandHandler("im", im_cmd))
    app.add_handler(CommandHandler("noi", noi_cmd))
    app.add_handler(CommandHandler("cam", cam_cmd))
    app.add_handler(CommandHandler("sua", sua_cmd))
    app.add_handler(CommandHandler("clear", clear_cmd))

    # Thống kê
    app.add_handler(CommandHandler("status", status_cmd))
    app.add_handler(CommandHandler("log", log_cmd))

    # Voice
    app.add_handler(CommandHandler("voice", voice_cmd))

    # Ngôn riêng
    app.add_handler(CommandHandler("addngon", addngon_cmd))
    app.add_handler(CommandHandler("xemngon", xemngon_cmd))
    app.add_handler(CommandHandler("resetngon", resetngon_cmd))

    # Callbacks
    app.add_handler(CallbackQueryHandler(main_menu_callback, pattern="^main:"))
    app.add_handler(CallbackQueryHandler(help_callback, pattern="^help:"))
    app.add_handler(CallbackQueryHandler(help_all_callback, pattern="^help:all$"))
    app.add_handler(CallbackQueryHandler(lang_callback, pattern="^lang:"))
    app.add_handler(CallbackQueryHandler(bot_config_callback, pattern="^bot:"))

    # Message
    app.add_handler(MessageHandler(filters.Document.TXT, handle_ngon_file))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, bot_set_input))


# ═══════════════════════════════════════════
# USER SESSION
# ═══════════════════════════════════════════
async def _run_user_session(acc_id: int, acc: dict):
    """Chạy bot con qua Telethon."""
    from telethon import TelegramClient
    from telethon.sessions import StringSession
    from bot_manager.session_handlers import register_session_handlers

    client = TelegramClient(
        StringSession(acc["session"]),
        acc["api_id"], acc["api_hash"]
    )

    try:
        await client.connect()
        if not await client.is_user_authorized():
            return

        # Đăng ký handlers
        register_session_handlers(client, acc_id)

        await client.run_until_disconnected()
    except asyncio.CancelledError:
        pass
    except Exception as e:
        print(f"❌ Bot con session {acc_id} lỗi: {e}")
    finally:
        try:
            await client.disconnect()
        except Exception:
            pass