"""
Bảo mật bot con.
- Admin bot con = Người tạo + OWNER
"""
from database.db import db
from config import is_owner


def is_botcon_admin(acc_id: int, uid: int) -> bool:
    """Check user có phải admin bot con."""
    # Owner luôn admin
    if is_owner(uid):
        return True

    # Người tạo
    acc = db.get_account(acc_id)
    if not acc or acc["type"] != "bot":
        return False

    return acc["owner_uid"] == uid


def get_botcon_role(acc_id: int, uid: int) -> str:
    """Lấy vai trò."""
    if is_owner(uid):
        return "owner"
    if is_botcon_admin(acc_id, uid):
        return "admin"
    return "user"