"""
Handlers cho bot con dùng User Session.
KHÔNG có nút bấm, chỉ gõ lệnh.
Có /m — xem all lệnh.
"""
from telethon import events
from database.db import db


def register_session_handlers(client, acc_id: int):
    """Đăng ký handlers."""

    # ═══ /m — Xem all lệnh ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/m$"))
    async def m_cmd(event):
        text = (
            "📖 **DANH SÁCH LỆNH**\n\n"
            "━━━ **CƠ BẢN** ━━━\n"
            "• `/id` — Lấy ID\n"
            "• `/ping` — Test\n"
            "• `/lang vi|en` — Ngôn ngữ\n\n"
            "━━━ **VOICE** ━━━\n"
            "• `/voice <text>` — Text → MP3\n"
            "• `/giong` — DS giọng\n"
            "• `/thay <lang>` — Đổi giọng\n\n"
            "━━━ **SPAM** ━━━\n"
            "• `/tag @user` — Spam + tag\n"
            "• `/tag2 @user` — Tag ẩn\n"
            "• `/call <id>` — Call\n"
            "• `/treongon on|off` — Treo ngôn\n"
            "• `/set <giây>` — Delay spam\n"
            "• `/setcall <giây>` — Delay call\n"
            "• `/off` — Dừng spam\n\n"
            "━━━ **THỐNG KÊ** ━━━\n"
            "• `/log` — Log\n"
            "• `/status` — Trạng thái\n\n"
            "━━━ **MOD** ━━━\n"
            "• `/im <id>` — Im chat riêng\n"
            "• `/noi <id>` — Cho nói\n"
            "• `/cam <uid> <cid>` — Cam group\n"
            "• `/sua <uid> <cid>` — Bỏ cam\n"
            "• `/clear` — Xóa 200 tin\n\n"
            "━━━ **NGÔN** ━━━\n"
            "• `/addngon` — Thêm ngôn\n"
            "• `/xemngon` — Xem ngôn\n"
            "• `/resetngon` — Đổi về bot chủ"
        )
        await event.reply(text, parse_mode="md")

    # ═══ /id ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/id$"))
    async def id_cmd(event):
        me = await client.get_me()
        await event.reply(f"🆔 ID: `{me.id}`", parse_mode="md")

    # ═══ /ping ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/ping$"))
    async def ping_cmd(event):
        await event.reply("🏓 Pong!")

    # ═══ /lang ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/lang$"))
    async def lang_cmd(event):
        await event.reply(
            "🌐 **NGÔN NGỮ**\n\n"
            "• `/lang vi` — Tiếng Việt\n"
            "• `/lang en` — English"
        )

    @client.on(events.NewMessage(outgoing=True, pattern=r"^/lang\s+(vi|en)$"))
    async def lang_set(event):
        lang = event.pattern_match.group(1)
        await event.reply(f"✅ Đã đổi sang **{lang}**")

    # ═══ /voice ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/voice\s+(.+)"))
    async def voice_cmd(event):
        text = event.pattern_match.group(1)
        await event.reply(f"🎤 Đang xử lý: `{text[:50]}`", parse_mode="md")

    # ═══ /giong ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/giong$"))
    async def giong_cmd(event):
        await event.reply("🔊 **DS GIỌNG**\n• Nữ\n• Nam\n• Bé gái\n• Bé trai")

    # ═══ /thay ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/thay\s+(.+)"))
    async def thay_cmd(event):
        g = event.pattern_match.group(1)
        await event.reply(f"✅ Đã đổi giọng: {g}")

    # ═══ /tag ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/tag\s+(.+)"))
    async def tag_cmd(event):
        target = event.pattern_match.group(1).strip()
        await event.reply(
            f"🚀 **BẮT ĐẦU SPAM**\n\n"
            f"• Target: `{target}`\n"
            f"• Cách: 👤 User Session\n\n"
            f"💡 Tắt: `/off`",
            parse_mode="md"
        )

    # ═══ /tag2 ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/tag2\s+(.+)"))
    async def tag2_cmd(event):
        target = event.pattern_match.group(1).strip()
        await event.reply(f"🎭 Bắt đầu tag ẩn: {target}")

    # ═══ /call ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/call\s+(\d+)"))
    async def call_cmd(event):
        target = event.pattern_match.group(1)
        await event.reply(
            f"📞 **BẮT ĐẦU CALL**\n\n"
            f"• Target: `{target}`\n\n"
            f"💡 Tắt: `/off`",
            parse_mode="md"
        )

    # ═══ /treongon ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/treongon\s+(on|off)"))
    async def treongon_cmd(event):
        state = event.pattern_match.group(1)
        if state == "on":
            await event.reply("🔄 Treo ngôn: 🟢 ON\n💡 Tắt: `/off`")
        else:
            await event.reply("🔴 Treo ngôn: OFF")

    # ═══ /set ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/set\s+([\d.,]+)"))
    async def set_cmd(event):
        try:
            v = float(event.pattern_match.group(1).replace(",", "."))
            await event.reply(f"✅ Delay spam = {v}s")
        except ValueError:
            await event.reply("❌ Delay không hợp lệ.")

    # ═══ /setcall ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/setcall\s+([\d.,]+)"))
    async def setcall_cmd(event):
        try:
            v = float(event.pattern_match.group(1).replace(",", "."))
            await event.reply(f"✅ Delay call = {v}s")
        except ValueError:
            await event.reply("❌ Delay không hợp lệ.")

    # ═══ /off ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/off$"))
    async def off_cmd(event):
        await event.reply(
            "🔴 **ĐÃ DỪNG**\n\n"
            "• Spam/Tag: 🔴 OFF\n"
            "• Call: 🔴 OFF\n"
            "• Treo ngôn: 🔴 OFF\n\n"
            "⚠️ /im và /cam vẫn chạy."
        )

    # ═══ /log ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/log$"))
    async def log_cmd(event):
        await event.reply(
            "📊 **LOG**\n\n"
            "🚀 Spam: 🔴 OFF\n"
            "📞 Call: 🔴 OFF\n"
            "🔄 Treo ngôn: 🔴 OFF"
        )

    # ═══ /status ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/status$"))
    async def status_cmd(event):
        await event.reply(
            "📊 **TRẠNG THÁI**\n\n"
            "🚀 Spam: 🔴 OFF\n"
            "📞 Call: 🔴 OFF\n"
            "🔄 Treo ngôn: 🔴 OFF"
        )

    # ═══ /im ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/im\s+(\d+)"))
    async def im_cmd(event):
        target = event.pattern_match.group(1)
        await event.reply(f"🔇 Đã im: `{target}`", parse_mode="md")

    # ═══ /noi ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/noi\s+(\d+)"))
    async def noi_cmd(event):
        target = event.pattern_match.group(1)
        await event.reply(f"🔊 Đã cho nói: `{target}`", parse_mode="md")

    # ═══ /cam ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/cam\s+(\d+)\s+(-?\d+)"))
    async def cam_cmd(event):
        uid_t = event.pattern_match.group(1)
        cid = event.pattern_match.group(2)
        await event.reply(f"🔇 Đã cam: `{uid_t}` trong `{cid}`", parse_mode="md")

    # ═══ /sua ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/sua\s+(\d+)\s+(-?\d+)"))
    async def sua_cmd(event):
        await event.reply("🔊 Đã bỏ cam.")

    # ═══ /clear ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/clear$"))
    async def clear_cmd(event):
        await event.reply("🗑️ Đã xóa 200 tin.")

    # ═══ /addngon ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/addngon$"))
    async def addngon_cmd(event):
        await event.reply(
            "📎 **THÊM NGÔN RIÊNG**\n\n"
            "Gửi file .txt (mỗi dòng 1 câu).\n\n"
            "💡 Ngôn sẽ thay thế ngôn bot chủ.\n"
            "🔄 Có thể đổi lại bất kỳ lúc nào.",
            parse_mode="md"
        )

    # ═══ /xemngon ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/xemngon$"))
    async def xemngon_cmd(event):
        await event.reply("📚 Đang gửi ngôn...")

    # ═══ /resetngon ═══
    @client.on(events.NewMessage(outgoing=True, pattern=r"^/resetngon$"))
    async def resetngon_cmd(event):
        await event.reply("🔄 Đã đổi về ngôn bot chủ.")