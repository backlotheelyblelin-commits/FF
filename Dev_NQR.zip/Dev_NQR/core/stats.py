"""Đếm tin gửi/lỗi."""
import time


class Stats:
    def __init__(self):
        self.data: dict[int, dict] = {}

    def start(self, uid, targets=0):
        self.data[uid] = {
            "targets": targets,
            "sent": 0,
            "failed": 0,
            "start_time": time.time(),
            "running": True,
        }

    def inc_sent(self, uid, n=1):
        if uid in self.data:
            self.data[uid]["sent"] += n

    def inc_failed(self, uid, n=1):
        if uid in self.data:
            self.data[uid]["failed"] += n

    def stop(self, uid):
        if uid in self.data:
            self.data[uid]["running"] = False

    def reset(self, uid):
        self.data.pop(uid, None)

    def get(self, uid):
        return self.data.get(uid)

    def elapsed(self, uid):
        s = self.data.get(uid)
        return time.time() - s["start_time"] if s else 0.0

    def speed(self, uid):
        s = self.data.get(uid)
        if not s:
            return 0.0
        e = self.elapsed(uid)
        return s["sent"] / e if e > 0 else 0.0

    def total_sent(self):
        return sum(s["sent"] for s in self.data.values())

    def total_failed(self):
        return sum(s["failed"] for s in self.data.values())

    def running_count(self):
        return sum(1 for s in self.data.values() if s["running"])


stats = Stats()