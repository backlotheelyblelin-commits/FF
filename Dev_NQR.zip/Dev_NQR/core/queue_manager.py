"""Quản lý task multi-kind."""
import asyncio


class QueueManager:
    def __init__(self):
        self.tasks: dict[int, dict[str, list]] = {}

    def register(self, uid, task, kind="spam"):
        self.tasks.setdefault(uid, {}).setdefault(kind, []).append(task)

    def stop_spam_user(self, uid):
        """Chỉ dừng spam/call/treongon."""
        for kind in ("spam", "call", "treongon"):
            for t in self.tasks.get(uid, {}).get(kind, []):
                if not t.done():
                    t.cancel()
            self.tasks.setdefault(uid, {})[kind] = []

    def stop_mod_user(self, uid):
        """Chỉ dừng im/cam."""
        for kind in ("im", "cam"):
            for t in self.tasks.get(uid, {}).get(kind, []):
                if not t.done():
                    t.cancel()
            self.tasks.setdefault(uid, {})[kind] = []

    def stop_user(self, uid):
        """Dừng TẤT CẢ."""
        for kind in list(self.tasks.get(uid, {})):
            for t in self.tasks[uid][kind]:
                if not t.done():
                    t.cancel()
        self.tasks[uid] = {}

    def stop_all(self):
        for uid in list(self.tasks.keys()):
            self.stop_user(uid)
        self.tasks.clear()

    def is_running(self, uid, kind=None):
        if kind:
            return any(not t.done() for t in self.tasks.get(uid, {}).get(kind, []))
        for k in self.tasks.get(uid, {}):
            if any(not t.done() for t in self.tasks[uid][k]):
                return True
        return False

    def count_running(self):
        total = 0
        for uid in self.tasks:
            for kind in self.tasks[uid]:
                total += sum(1 for t in self.tasks[uid][kind] if not t.done())
        return total

    def running_users(self):
        return [u for u in self.tasks if self.is_running(u)]


queue_manager = QueueManager()