"""Anti FloodWait."""
import asyncio
import time


class RateLimiter:
    def __init__(self):
        self.enabled = False
        self._last = 0.0
        self._paused_until = 0.0
        self.delay = 1.0

    def enable(self):
        self.enabled = True

    def disable(self):
        self.enabled = False

    def set_delay(self, seconds):
        self.delay = max(0.1, min(3600.0, float(seconds)))

    async def acquire(self):
        if not self.enabled:
            return
        now = time.time()
        if now < self._paused_until:
            await asyncio.sleep(self._paused_until - now)
        wait = self._last + self.delay - time.time()
        if wait > 0:
            await asyncio.sleep(wait)
        self._last = time.time()

    def handle_flood(self, retry_after):
        self._paused_until = time.time() + retry_after + 1

    @property
    def is_paused(self):
        return time.time() < self._paused_until

    @property
    def pause_remaining(self):
        return max(0.0, self._paused_until - time.time())


rate_limiter = RateLimiter()