"""
Database SQLite cho bot Dev_NQR.
Tự tạo data/bot.db + 8 bảng khi chạy lần đầu.
"""
import sqlite3
from pathlib import Path

# Đường dẫn tuyệt đối → chạy từ đâu cũng OK
BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "data" / "bot.db"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)


class Database:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    # ═══════════════════════════════════════════
    # SCHEMA — Tự tạo 8 bảng
    # ═══════════════════════════════════════════
    def _init_schema(self):
        self.conn.executescript("""
            -- Bảng 1: Tài khoản (Bot Token + User Session)
            CREATE TABLE IF NOT EXISTS accounts (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_uid   INTEGER NOT NULL,
                name        TEXT NOT NULL,
                type        TEXT NOT NULL,           -- 'bot' | 'user'
                token       TEXT,                    -- Bot Token
                api_id      INTEGER,                 -- User Session
                api_hash    TEXT,
                phone       TEXT,
                session     TEXT,
                info        TEXT,
                status      TEXT DEFAULT 'pending',  -- pending | active | banned
                is_default  INTEGER DEFAULT 0,
                created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(owner_uid, name)
            );

            -- Bảng 2: Admin
            CREATE TABLE IF NOT EXISTS admins (
                uid      INTEGER PRIMARY KEY,
                added_by INTEGER,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            -- Bảng 3: Delay spam/call
            CREATE TABLE IF NOT EXISTS delays (
                uid         INTEGER PRIMARY KEY,
                spam_delay  REAL DEFAULT 1.0,
                call_delay  REAL DEFAULT 3.0
            );

            -- Bảng 4: Trạng thái on/off
            CREATE TABLE IF NOT EXISTS states (
                uid         INTEGER PRIMARY KEY,
                spam_on     INTEGER DEFAULT 0,
                call_on     INTEGER DEFAULT 0,
                treongon_on INTEGER DEFAULT 0
            );

            -- Bảng 5: User bị im (chat riêng)
            CREATE TABLE IF NOT EXISTS blocked (
                uid        INTEGER,
                target_uid INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (uid, target_uid)
            );

            -- Bảng 6: Cam list (group)
            CREATE TABLE IF NOT EXISTS cam_list (
                owner_uid  INTEGER,
                target_uid INTEGER,
                chat_id    INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (owner_uid, target_uid, chat_id)
            );

            -- Bảng 7: Setting riêng user
            CREATE TABLE IF NOT EXISTS user_settings (
                uid   INTEGER,
                key   TEXT,
                value TEXT,
                PRIMARY KEY (uid, key)
            );

            -- Bảng 8: Audit log
            CREATE TABLE IF NOT EXISTS audit_log (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                uid        INTEGER,
                action     TEXT,
                detail     TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        self.conn.commit()

    # ═══════════════════════════════════════════
    # ACCOUNTS — Tài khoản
    # ═══════════════════════════════════════════
    def count_accounts(self, uid: int) -> int:
        """Đếm tổng acc (không tính rejected)."""
        cur = self.conn.execute(
            "SELECT COUNT(*) FROM accounts WHERE owner_uid = ? AND status != 'rejected'",
            (uid,)
        )
        return cur.fetchone()[0]

    def count_bot_tokens(self, uid: int) -> int:
        """Đếm riêng Bot Token."""
        cur = self.conn.execute(
            "SELECT COUNT(*) FROM accounts "
            "WHERE owner_uid = ? AND type = 'bot' AND status != 'rejected'",
            (uid,)
        )
        return cur.fetchone()[0]

    def count_user_sessions(self, uid: int) -> int:
        """Đếm riêng User Session."""
        cur = self.conn.execute(
            "SELECT COUNT(*) FROM accounts "
            "WHERE owner_uid = ? AND type = 'user' AND status != 'rejected'",
            (uid,)
        )
        return cur.fetchone()[0]

    def add_account(self, owner_uid: int, name: str, type_: str, **kw) -> int:
        """Thêm acc. Trả về acc_id."""
        cur = self.conn.execute("""
            INSERT INTO accounts
                (owner_uid, name, type, token, api_id, api_hash,
                 phone, session, info, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            owner_uid, name, type_,
            kw.get("token", ""),
            kw.get("api_id"),
            kw.get("api_hash"),
            kw.get("phone", ""),
            kw.get("session", ""),
            kw.get("info", ""),
            kw.get("status", "pending"),
        ))
        self.conn.commit()
        return cur.lastrowid

    def get_account(self, acc_id: int):
        """Lấy 1 acc theo ID."""
        cur = self.conn.execute("SELECT * FROM accounts WHERE id = ?", (acc_id,))
        row = cur.fetchone()
        return dict(row) if row else None

    def get_accounts(self, owner_uid: int = None, status: str = None, type_: str = None) -> list:
        """Lấy DS acc, có thể filter."""
        q = "SELECT * FROM accounts WHERE 1=1"
        args = []
        if owner_uid is not None:
            q += " AND owner_uid = ?"
            args.append(owner_uid)
        if status:
            q += " AND status = ?"
            args.append(status)
        if type_:
            q += " AND type = ?"
            args.append(type_)
        q += " ORDER BY id DESC"
        return [dict(r) for r in self.conn.execute(q, args).fetchall()]

    def update_account(self, acc_id: int, **fields):
        """Cập nhật acc."""
        if not fields:
            return
        sets = ", ".join(f"{k} = ?" for k in fields)
        vals = list(fields.values()) + [acc_id]
        self.conn.execute(f"UPDATE accounts SET {sets} WHERE id = ?", vals)
        self.conn.commit()

    def delete_account(self, acc_id: int, owner_uid: int = None):
        """Xóa acc. Nếu có owner_uid → chỉ xóa nếu đúng chủ."""
        if owner_uid is not None:
            self.conn.execute(
                "DELETE FROM accounts WHERE id = ? AND owner_uid = ?",
                (acc_id, owner_uid)
            )
        else:
            self.conn.execute("DELETE FROM accounts WHERE id = ?", (acc_id,))
        self.conn.commit()

    def get_default_account(self, uid: int):
        """Lấy acc mặc định của user."""
        # Ưu tiên acc default
        cur = self.conn.execute(
            "SELECT * FROM accounts WHERE owner_uid = ? AND is_default = 1 LIMIT 1",
            (uid,)
        )
        row = cur.fetchone()
        if row:
            return dict(row)

        # Fallback: acc active đầu tiên
        cur = self.conn.execute(
            "SELECT * FROM accounts WHERE owner_uid = ? AND status = 'active' LIMIT 1",
            (uid,)
        )
        row = cur.fetchone()
        return dict(row) if row else None

    def set_default(self, acc_id: int, uid: int):
        """Đặt acc làm mặc định."""
        # Bỏ default cũ
        self.conn.execute(
            "UPDATE accounts SET is_default = 0 WHERE owner_uid = ?", (uid,)
        )
        # Set default mới
        self.conn.execute(
            "UPDATE accounts SET is_default = 1 WHERE id = ? AND owner_uid = ?",
            (acc_id, uid)
        )
        self.conn.commit()

    # ═══════════════════════════════════════════
    # ADMINS — Quản lý admin
    # ═══════════════════════════════════════════
    def is_admin(self, uid: int) -> bool:
        cur = self.conn.execute("SELECT 1 FROM admins WHERE uid = ?", (uid,))
        return cur.fetchone() is not None

    def add_admin(self, uid: int, by: int):
        self.conn.execute(
            "INSERT OR IGNORE INTO admins (uid, added_by) VALUES (?, ?)",
            (uid, by)
        )
        self.conn.commit()

    def remove_admin(self, uid: int):
        self.conn.execute("DELETE FROM admins WHERE uid = ?", (uid,))
        self.conn.commit()

    def get_all_admins(self) -> list:
        return [dict(r) for r in self.conn.execute("SELECT * FROM admins").fetchall()]

    # ═══════════════════════════════════════════
    # DELAYS — Delay spam/call
    # ═══════════════════════════════════════════
    def get_delay(self, uid: int, kind: str = "spam") -> float:
        """kind = 'spam' | 'call'."""
        cur = self.conn.execute(
            "SELECT spam_delay, call_delay FROM delays WHERE uid = ?", (uid,)
        )
        row = cur.fetchone()
        if not row:
            return 1.0 if kind == "spam" else 3.0
        return row["spam_delay"] if kind == "spam" else row["call_delay"]

    def set_delay(self, uid: int, kind: str, value: float):
        col = "spam_delay" if kind == "spam" else "call_delay"
        self.conn.execute(f"""
            INSERT INTO delays (uid, {col}) VALUES (?, ?)
            ON CONFLICT(uid) DO UPDATE SET {col} = excluded.{col}
        """, (uid, value))
        self.conn.commit()

    # ═══════════════════════════════════════════
    # STATES — Trạng thái on/off
    # ═══════════════════════════════════════════
    def get_state(self, uid: int) -> dict:
        cur = self.conn.execute("SELECT * FROM states WHERE uid = ?", (uid,))
        row = cur.fetchone()
        if row:
            return dict(row)
        return {"uid": uid, "spam_on": 0, "call_on": 0, "treongon_on": 0}

    def set_state(self, uid: int, **fields):
        self.conn.execute("INSERT OR IGNORE INTO states (uid) VALUES (?)", (uid,))
        if fields:
            sets = ", ".join(f"{k} = ?" for k in fields)
            vals = list(fields.values()) + [uid]
            self.conn.execute(f"UPDATE states SET {sets} WHERE uid = ?", vals)
            self.conn.commit()

    # ═══════════════════════════════════════════
    # BLOCKED — Im chat riêng
    # ═══════════════════════════════════════════
    def block_user(self, uid: int, target_uid: int):
        self.conn.execute(
            "INSERT OR REPLACE INTO blocked (uid, target_uid) VALUES (?, ?)",
            (uid, target_uid)
        )
        self.conn.commit()

    def unblock_user(self, uid: int, target_uid: int):
        self.conn.execute(
            "DELETE FROM blocked WHERE uid = ? AND target_uid = ?",
            (uid, target_uid)
        )
        self.conn.commit()

    def is_blocked(self, uid: int, target_uid: int) -> bool:
        cur = self.conn.execute(
            "SELECT 1 FROM blocked WHERE uid = ? AND target_uid = ?",
            (uid, target_uid)
        )
        return cur.fetchone() is not None

    def get_blocked(self, uid: int) -> list:
        cur = self.conn.execute(
            "SELECT target_uid FROM blocked WHERE uid = ?", (uid,)
        )
        return [r[0] for r in cur.fetchall()]

    # ═══════════════════════════════════════════
    # CAM LIST — Cam group
    # ═══════════════════════════════════════════
    def add_cam(self, owner_uid: int, target_uid: int, chat_id: int):
        self.conn.execute(
            "INSERT OR REPLACE INTO cam_list (owner_uid, target_uid, chat_id) VALUES (?, ?, ?)",
            (owner_uid, target_uid, chat_id)
        )
        self.conn.commit()

    def remove_cam(self, owner_uid: int, target_uid: int, chat_id: int):
        self.conn.execute(
            "DELETE FROM cam_list WHERE owner_uid = ? AND target_uid = ? AND chat_id = ?",
            (owner_uid, target_uid, chat_id)
        )
        self.conn.commit()

    def is_cam(self, owner_uid: int, target_uid: int, chat_id: int) -> bool:
        cur = self.conn.execute(
            "SELECT 1 FROM cam_list WHERE owner_uid = ? AND target_uid = ? AND chat_id = ?",
            (owner_uid, target_uid, chat_id)
        )
        return cur.fetchone() is not None

    def get_cams(self, owner_uid: int) -> list:
        cur = self.conn.execute(
            "SELECT * FROM cam_list WHERE owner_uid = ?", (owner_uid,)
        )
        return [dict(r) for r in cur.fetchall()]

    # ═══════════════════════════════════════════
    # USER SETTINGS — Setting riêng user
    # ═══════════════════════════════════════════
    def get_user_setting(self, uid: int, key: str, default=None):
        import json
        cur = self.conn.execute(
            "SELECT value FROM user_settings WHERE uid = ? AND key = ?",
            (uid, key)
        )
        row = cur.fetchone()
        if not row:
            return default
        try:
            return json.loads(row["value"])
        except Exception:
            return default

    def set_user_setting(self, uid: int, key: str, value):
        import json
        self.conn.execute(
            "INSERT OR REPLACE INTO user_settings (uid, key, value) VALUES (?, ?, ?)",
            (uid, key, json.dumps(value))
        )
        self.conn.commit()

    # ═══════════════════════════════════════════
    # AUDIT LOG — Lịch sử thao tác
    # ═══════════════════════════════════════════
    def log(self, uid: int, action: str, detail: str = ""):
        self.conn.execute(
            "INSERT INTO audit_log (uid, action, detail) VALUES (?, ?, ?)",
            (uid, action, detail)
        )
        self.conn.commit()

    def get_log(self, limit: int = 100) -> list:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()]

    # ═══════════════════════════════════════════
    # STATS — Thống kê
    # ═══════════════════════════════════════════
    def get_stats(self) -> dict:
        tables = ["accounts", "admins", "delays", "states", "blocked", "cam_list", "user_settings", "audit_log"]
        result = {}
        for t in tables:
            cur = self.conn.execute(f"SELECT COUNT(*) FROM {t}")
            result[t] = cur.fetchone()[0]
        return result

    def size_mb(self) -> float:
        if DB_PATH.exists():
            return DB_PATH.stat().st_size / (1024 * 1024)
        return 0.0


# Singleton — import 1 lần, dùng toàn project
db = Database()