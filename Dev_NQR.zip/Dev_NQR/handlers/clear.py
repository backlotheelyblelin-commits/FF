"""/clear — Xóa 200 tin."""
import asyncio
from telegram import Update
from telegram.ext import ContextTypes
from utils.autodelete import delete_cmd

MAX_CLEAR = 200
BATCH_SIZE = 100


async def clear_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    chat = update.effective_chat
    uid = update.effective_user.id

    count = MAX_CLEAR
    if ctx.args and ctx.args[0].isdigit():
        count = min(int(ctx.args[0]), MAX_CLEAR)

    current_id = update.message.message_id

    try:
        await update.message.delete()
    except Exception:
        pass

    deleted, failed = 0, 0

    msg_ids = [current_id - i for i in range(1, count + 1) if current_id - i > 0]

    for i in range(0, len(msg_ids), BATCH_SIZE):
        batch = msg_ids[i:i + BATCH_SIZE]
        try:
            await ctx.bot.delete_messages(chat.id, batch)
            deleted += len(batch)
        except Exception:
            for mid in batch:
                try:
                    await ctx.bot.delete_message(chat.id, mid)
                    deleted += 1
                except Exception:
                    failed += 1
                await asyncio.sleep(0.02)
        await asyncio.sleep(0.05)

    try:
        msg = await ctx.bot.send_message(chat.id, f"🗑️ Đã xóa {deleted} tin.")
        await asyncio.sleep(1)
        await msg.delete()
    except Exception:
        pass