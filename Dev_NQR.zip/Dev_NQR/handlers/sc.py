"""
/sc on|off — Auto copy.
"""
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from utils.autodelete import delete_cmd


async def sc_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not ctx.args:
        cur = db.get_user_setting(uid, "sc", False)
        await update.message.reply_text(
            f"📋 Auto-copy: {'🟢 ON' if cur else '🔴 OFF'}\n\n"
            f"Dùng: `/sc on` hoặc `/sc off`",
            parse_mode="Markdown"
        )
        return

    arg = ctx.args[0].lower()
    if arg not in ("on", "off"):
        await update.message.reply_text("Dùng: `/sc on` hoặc `/sc off`", parse_mode="Markdown")
        return

    state = arg == "on"
    db.set_user_setting(uid, "sc", state)

    await update.message.reply_text(
        f"📋 Auto-copy: {'🟢 ON' if state else '🔴 OFF'}",
        parse_mode="Markdown"
    )