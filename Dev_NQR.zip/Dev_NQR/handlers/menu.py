"""/mn, /help — DS lệnh."""
from telegram import Update
from telegram.ext import ContextTypes
from utils.keyboards import btn, build_menu
from utils.autodelete import delete_cmd
from utils.menu_builder import get_help_rows
from config import is_owner, is_admin


HELP_USER = """📖 **LỆNH USER**

🔹 Cơ bản:
`/start` `/mn` `/help` `/id` `/ping` `/lang`

🔹 Voice:
`/voice` `/giong` `/thay`

🔹 Spam:
`/tag` `/tag2` `/call` `/treongon`
`/set` `/setcall` `/off`

🔹 Thống kê:
`/log` `/status`

🔹 Tài khoản:
`/addtk` `/mytk` `/checktk` `/settk` `/deltk`

🔹 Mod:
`/im` `/noi` `/cam` `/sua`
`/sc` `/anti` `/clear`
"""

HELP_ADMIN = """👮 **LỆNH ADMIN**

🔹 Ngôn:
`/add` `/add2` `/addtreo`
`/listngon` `/delngon` `/clearngon`

🔹 Tài khoản:
`/duyet` `/tuclioi` `/alltk`

🔹 Thống kê:
`/globalstatus`
"""

HELP_OWNER = """👑 **LỆNH OWNER**

🔹 Hệ thống:
`/offall` `/logall` `/broadcast`

🔹 Quản lý admin:
`/setadmin` `/deladmin` `/listadmin` `/setquyen`

🔹 Cấu hình:
`/sl`

🔹 Database:
`/backup` `/restore` `/dbcheck` `/dblist` `/dbclean`

🔹 Khác:
`/blacklist` `/whitelist` `/monitor`
"""


async def mn_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    is_botcon = ctx.bot_data.get("is_botcon", False)
    await mn_menu(update.message.reply_text, update.effective_user.id, is_botcon)


async def mn_menu(reply, uid, is_botcon=False):
    rows = get_help_rows(uid, is_botcon)
    await reply(
        "📖 **DANH SÁCH LỆNH**\n\nChọn loại:",
        parse_mode="Markdown",
        reply_markup=build_menu(*rows)
    )


async def help_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    parts = query.data.split(":")
    data = parts[1] if len(parts) > 1 else "main"

    is_botcon = ctx.bot_data.get("is_botcon", False)

    if data == "main":
        await mn_menu(query.edit_message_text, update.effective_user.id, is_botcon)
        return

    uid = update.effective_user.id

    if data == "user":
        text = HELP_USER
    elif data == "admin":
        if is_botcon or not is_admin(uid):
            await query.answer("⛔ Không có quyền.", show_alert=True)
            return
        text = HELP_ADMIN
    elif data == "owner":
        if is_botcon or not is_owner(uid):
            await query.answer("⛔ Không có quyền.", show_alert=True)
            return
        text = HELP_OWNER
    else:
        text = "❌ Không tồn tại."

    await query.edit_message_text(
        text,
        reply_markup=build_menu([btn("🔙 Quay lại", "help:main")])
    )