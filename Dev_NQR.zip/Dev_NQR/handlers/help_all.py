"""Nút Xem ALL lệnh."""
from telegram import Update
from telegram.ext import ContextTypes
from utils.keyboards import btn, build_menu


ALL_COMMANDS_TEXT = (
    "📋 **TẤT CẢ LỆNH**\n\n"
    "━━━ **CƠ BẢN** ━━━\n"
    "• `/start` — Menu chính\n"
    "• `/mn` — DS lệnh\n"
    "• `/help` — Trợ giúp\n"
    "• `/id` — Lấy ID\n"
    "• `/ping` — Test\n"
    "• `/lang` — Ngôn ngữ\n\n"
    "━━━ **VOICE** ━━━\n"
    "• `/voice <text>` — Text → MP3\n"
    "• `/giong` — DS giọng\n"
    "• `/thay <lang>` — Đổi giọng\n\n"
    "━━━ **SPAM** ━━━\n"
    "• `/tag @user` — Spam + tag\n"
    "• `/tag2 @user` — Tag ẩn\n"
    "• `/call <id>` — Call\n"
    "• `/treongon on|off` — Treo ngôn\n"
    "• `/set <giây>` — Delay spam\n"
    "• `/setcall <giây>` — Delay call\n"
    "• `/off` — Dừng spam\n\n"
    "━━━ **THỐNG KÊ** ━━━\n"
    "• `/log` — Log của mình\n"
    "• `/status` — Trạng thái\n\n"
    "━━━ **MOD** ━━━\n"
    "• `/im <id>` — Im chat riêng\n"
    "• `/noi <id>` — Cho nói\n"
    "• `/cam <uid> <cid>` — Cam group\n"
    "• `/sua <uid> <cid>` — Bỏ cam\n"
    "• `/clear` — Xóa 200 tin\n\n"
    "━━━ **NGÔN** ━━━\n"
    "• `/addngon` — Thêm ngôn\n"
    "• `/xemngon` — Xem ngôn\n"
    "• `/resetngon` — Đổi về bot chủ"
)


async def help_all_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await query.edit_message_text(
        ALL_COMMANDS_TEXT,
        parse_mode="Markdown",
        reply_markup=build_menu([btn("🔙 Quay lại", "main:menu")])
    )