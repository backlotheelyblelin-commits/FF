"""/ping — Test bot."""
import time
from telegram import Update
from telegram.ext import ContextTypes
from utils.autodelete import delete_cmd


async def ping_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    start = time.time()
    msg = await update.message.reply_text("🏓 Pong...")
    latency = (time.time() - start) * 1000
    await msg.edit_text(f"🏓 Pong! `{latency:.0f}ms`", parse_mode="Markdown")