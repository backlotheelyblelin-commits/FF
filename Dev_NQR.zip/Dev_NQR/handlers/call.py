"""/call — Gọi liên tục."""
import asyncio
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from core.queue_manager import queue_manager
from core.rate_limiter import rate_limiter
from utils.autodelete import delete_cmd
from config import MIN_DELAY, MAX_DELAY


async def setcall_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not ctx.args:
        cur = db.get_delay(uid, "call")
        await update.message.reply_text(
            f"📞 Delay call: **{cur}s**\nDùng: `/setcall <giây>`\nMin: {MIN_DELAY} - Max: {MAX_DELAY}",
            parse_mode="Markdown"
        )
        return

    try:
        val = float(ctx.args[0].replace(",", "."))
    except ValueError:
        await update.message.reply_text("❌ Phải là số.")
        return

    real = max(MIN_DELAY, min(MAX_DELAY, val))
    db.set_delay(uid, "call", real)
    await update.message.reply_text(f"✅ Delay call = **{real}s**", parse_mode="Markdown")


async def call_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not ctx.args:
        await update.message.reply_text("Dùng: `/call <id>`", parse_mode="Markdown")
        return

    try:
        target = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID phải là số.")
        return

    acc = db.get_default_account(uid)
    if not acc:
        await update.message.reply_text("⚠️ Chưa có acc.")
        return

    if acc["type"] != "user":
        await update.message.reply_text(
            "⚠️ Call cần **User Session**.\nBot Token không call được.",
            parse_mode="Markdown"
        )
        return

    delay = db.get_delay(uid, "call")

    if queue_manager.is_running(uid, "call"):
        queue_manager.stop_user(uid)

    task = asyncio.create_task(_call_worker(ctx, uid, target, acc, delay))
    queue_manager.register(uid, task, kind="call")

    await update.message.reply_text(
        f"📞 **BẮT ĐẦU CALL**\n\n"
        f"• Target: `{target}`\n"
        f"• Acc: 👤 User Session\n"
        f"• Delay: {delay}s\n\n"
        f"🟢 Call: ON\n\n"
        f"💡 Tắt: `/off`",
        parse_mode="Markdown"
    )


async def _call_worker(ctx, uid, target, acc, delay):
    from telethon import TelegramClient
    from telethon.sessions import StringSession
    from telethon.errors import FloodWaitError

    client = TelegramClient(StringSession(acc["session"]), acc["api_id"], acc["api_hash"])
    calls = 0
    failed = 0

    try:
        await client.connect()
        if not await client.is_user_authorized():
            return

        entity = await client.get_entity(target)
        if getattr(entity, "bot", False):
            return

        while True:
            try:
                await rate_limiter.acquire()
                await client.request_call(target)
                calls += 1
                await asyncio.sleep(1)
                try:
                    await client.discard_call(target)
                except Exception:
                    pass
                await asyncio.sleep(delay)
            except asyncio.CancelledError:
                break
            except FloodWaitError as e:
                rate_limiter.handle_flood(e.seconds)
                await asyncio.sleep(e.seconds + 1)
            except Exception:
                failed += 1
                await asyncio.sleep(delay)
    except asyncio.CancelledError:
        pass
    finally:
        try:
            await client.disconnect()
        except Exception:
            pass
        try:
            await ctx.bot.send_message(uid, f"🛑 Call dừng. Đã gọi: {calls}, lỗi: {failed}")
        except Exception:
            pass