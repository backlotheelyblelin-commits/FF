"""
/mytk — Quản lý tài khoản.
Token: 3 | Session: ∞
"""
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from utils.keyboards import btn, build_menu
from utils.autodelete import delete_cmd
from config import get_token_limit


def _is_botcon(ctx) -> bool:
    return ctx.bot_data.get("is_botcon", False) if ctx else False


def _icon(status: str) -> str:
    return {
        "active": "🟢", "pending": "🟡",
        "banned": "🔴", "rejected": "⚫",
    }.get(status, "❔")


async def mytk_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    await show_list(update.message.reply_text, update.effective_user.id, ctx)


async def show_list(reply, uid: int, ctx=None):
    accs = db.get_accounts(owner_uid=uid)
    is_botcon = _is_botcon(ctx)

    tokens = [a for a in accs if a["type"] == "bot"]
    sessions = [a for a in accs if a["type"] == "user"]

    token_lim = get_token_limit(uid)
    token_show = "∞" if token_lim > 1000 else str(token_lim)

    text = "👤 **TÀI KHOẢN CỦA BẠN**\n\n"

    if tokens:
        text += f"━━━ 🤖 **TOKEN** ({len(tokens)}/{token_show}) ━━━\n"
        for t in tokens:
            text += f"{_icon(t['status'])} `{t['name']}` #{t['id']}\n"
        text += "\n"

    if sessions:
        text += f"━━━ 👤 **SESSION** ({len(sessions)}/∞) ━━━\n"
        for s in sessions:
            text += f"{_icon(s['status'])} `{s['name']}` #{s['id']}\n"
        text += "\n"

    if not accs:
        text += "📭 Chưa có tài khoản nào.\n"

    rows = []
    for a in accs:
        icon = "🤖" if a["type"] == "bot" else "👤"
        rows.append([btn(
            f"{_icon(a['status'])} {icon} {a['name']} #{a['id']}",
            f"mytk:view:{a['id']}"
        )])

    if not is_botcon:
        rows.append([btn("➕ Thêm tài khoản", "addtk:start")])

    rows.append([btn("🔙 Quay lại", "main:menu")])

    await reply(text, parse_mode="Markdown", reply_markup=build_menu(*rows))


async def mytk_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid = update.effective_user.id
    parts = query.data.split(":")
    action = parts[1]

    if action == "list":
        await show_list(query.edit_message_text, uid, ctx)
        return

    if action == "view":
        acc_id = int(parts[2])
        await _show_detail(query, acc_id, uid, ctx)
        return

    if action == "default":
        acc_id = int(parts[2])
        db.set_default(acc_id, uid)
        await query.answer("⭐ Đã đặt mặc định!", show_alert=True)
        await _show_detail(query, acc_id, uid, ctx)
        return

    if action == "del":
        if _is_botcon(ctx):
            await query.answer("⛔ Bot con không xóa acc.\nVào bot chủ.", show_alert=True)
            return
        acc_id = int(parts[2])
        acc = db.get_account(acc_id)
        if acc and acc["owner_uid"] == uid:
            db.delete_account(acc_id, owner_uid=uid)
            await query.answer("🗑️ Đã xóa!", show_alert=True)
        await show_list(query.edit_message_text, uid, ctx)
        return


async def _show_detail(query, acc_id: int, uid: int, ctx=None):
    acc = db.get_account(acc_id)
    if not acc or acc["owner_uid"] != uid:
        await query.answer("❌ Không tìm thấy.", show_alert=True)
        return

    icon = "🤖" if acc["type"] == "bot" else "👤"
    status = {
        "active": "🟢 Đang hoạt động",
        "pending": "🟡 Chờ duyệt",
        "banned": "🔴 Bị khóa",
        "rejected": "⚫ Bị từ chối",
    }.get(acc["status"], "❔")

    is_default = "⭐ Có" if acc.get("is_default") else "❌ Không"

    text = (
        f"📋 **CHI TIẾT ACC #{acc_id}**\n\n"
        f"• Tên: `{acc['name']}`\n"
        f"• Loại: {icon} {acc['type']}\n"
        f"• Info: {acc.get('info', '?')}\n"
        f"• Trạng thái: {status}\n"
        f"• Mặc định: {is_default}"
    )

    rows = [
        [btn("⭐ Set default", f"mytk:default:{acc_id}")],
    ]

    if not _is_botcon(ctx):
        rows.append([btn("🗑️ Xóa acc", f"mytk:del:{acc_id}")])

    rows.append([btn("🔙 Quay lại", "mytk:list")])

    await query.edit_message_text(
        text, parse_mode="Markdown", reply_markup=build_menu(*rows)
    )