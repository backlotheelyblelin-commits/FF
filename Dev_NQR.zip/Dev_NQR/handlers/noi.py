"""
/noi <uid> — Cho nói lại (tắt /im).
"""
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from core.queue_manager import queue_manager
from utils.autodelete import delete_cmd


async def noi_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not ctx.args:
        await update.message.reply_text(
            "📌 Dùng: `/noi <uid>`\n"
            "VD: `/noi 123456789`",
            parse_mode="Markdown"
        )
        return

    try:
        target = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ UID phải là số.")
        return

    # Kiểm tra có bật im không
    if not db.is_blocked(uid, target):
        await update.message.reply_text(
            f"⚠️ Bạn chưa im `{target}`.\n"
            f"Dùng `/im {target}` để bật.",
            parse_mode="Markdown"
        )
        return

    db.unblock_user(uid, target)
    queue_manager.stop_user(uid)
    db.log(uid, "noi", str(target))

    await update.message.reply_text(
        f"🔊 **ĐÃ CHO NÓI LẠI**\n\n"
        f"• User: `{target}`\n\n"
        f"💡 Tin họ gửi sẽ hiện bình thường.",
        parse_mode="Markdown"
    )