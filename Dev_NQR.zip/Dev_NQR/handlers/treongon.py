"""
/treongon on|off — Treo ngôn.
Spam liên tục ngôn mode 3.
"""
import asyncio
import random
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from core.queue_manager import queue_manager
from core.rate_limiter import rate_limiter
from core.stats import stats
from utils.autodelete import delete_cmd


async def treongon_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not ctx.args:
        cur = db.get_user_setting(uid, "treongon", False)
        status = "🟢 ON" if cur else "🔴 OFF"
        await update.message.reply_text(
            f"🔄 **TREO NGÔN**: {status}\n\n"
            f"• `/treongon on` — bật\n"
            f"• `/treongon off` — tắt\n"
            f"• `/off` — dừng tất cả",
            parse_mode="Markdown"
        )
        return

    arg = ctx.args[0].lower()

    if arg == "off":
        db.set_user_setting(uid, "treongon", False)
        db.set_state(uid, treongon_on=0)
        queue_manager.stop_spam_user(uid)

        await update.message.reply_text(
            "🔴 **ĐÃ TẮT TREO NGÔN**\n\n"
            "🔄 Treo ngôn: OFF",
            parse_mode="Markdown"
        )
        return

    if arg != "on":
        await update.message.reply_text(
            "Dùng: `/treongon on` hoặc `/treongon off`",
            parse_mode="Markdown"
        )
        return

    # Bật treo ngôn
    target = None

    # Nếu reply → target là reply
    if update.message.reply_to_message:
        target = update.message.reply_to_message.from_user.id
    elif len(ctx.args) > 1:
        arg2 = ctx.args[1]
        if arg2.startswith("@"):
            target = arg2
        else:
            try:
                target = int(arg2)
            except ValueError:
                target = None

    acc = db.get_default_account(uid)
    if not acc:
        await update.message.reply_text("⚠️ Chưa có acc.")
        return

    # Lấy ngôn mode 3
    is_botcon = ctx.bot_data.get("is_botcon", False)
    if is_botcon:
        acc_id = ctx.bot_data.get("acc_id")
        from utils.ngon_loader import get_ngon_for_botcon
        ngon = get_ngon_for_botcon(acc_id, "3")
    else:
        from handlers.add import get_ngon
        ngon = get_ngon("3")

    if not ngon:
        await update.message.reply_text("❌ Chưa có ngôn cho treo.")
        return

    # Nếu target là group/chat hiện tại
    if not target:
        target = update.effective_chat.id

    delay = db.get_delay(uid, "spam")

    db.set_user_setting(uid, "treongon", True)
    db.set_state(uid, treongon_on=1)

    if queue_manager.is_running(uid, "treongon"):
        queue_manager.stop_user(uid)

    task = asyncio.create_task(_treongon_worker(ctx, uid, target, acc, ngon, delay))
    queue_manager.register(uid, task, kind="treongon")

    await update.message.reply_text(
        f"🔄 **TREO NGÔN: ON**\n\n"
        f"━━━ **THÔNG TIN** ━━━\n"
        f"• Target: `{target}`\n"
        f"• Delay: {delay}s\n"
        f"• Ngôn: {len(ngon)} câu\n\n"
        f"━━━ **ĐANG CHẠY** ━━━\n"
        f"🟢 Treo ngôn: ON\n\n"
        f"💡 **Tắt:** `/off` hoặc `/treongon off`",
        parse_mode="Markdown"
    )


async def _treongon_worker(ctx, uid, target, acc, ngon, delay):
    if acc["type"] == "bot":
        await _treongon_via_bot(ctx, uid, target, acc, ngon, delay)
    else:
        await _treongon_via_session(ctx, uid, target, acc, ngon, delay)


async def _treongon_via_bot(ctx, uid, target, acc, ngon, delay):
    from telegram import Bot
    from telegram.error import TelegramError, RetryAfter

    bot = Bot(token=acc["token"])
    stats.start(uid, targets=1)

    try:
        while True:
            try:
                await rate_limiter.acquire()
                text = random.choice(ngon)
                await bot.send_message(target, text)
                stats.inc_sent(uid)
                await asyncio.sleep(delay)
            except asyncio.CancelledError:
                break
            except RetryAfter as e:
                rate_limiter.handle_flood(e.retry_after)
                await asyncio.sleep(e.retry_after + 1)
            except TelegramError:
                stats.inc_failed(uid)
                await asyncio.sleep(delay)
    except asyncio.CancelledError:
        pass
    finally:
        stats.stop(uid)


async def _treongon_via_session(ctx, uid, target, acc, ngon, delay):
    from telethon import TelegramClient
    from telethon.sessions import StringSession
    from telethon.errors import FloodWaitError

    client = TelegramClient(
        StringSession(acc["session"]),
        acc["api_id"], acc["api_hash"]
    )

    stats.start(uid, targets=1)

    try:
        await client.connect()
        if not await client.is_user_authorized():
            return

        try:
            entity = await client.get_entity(target)
        except Exception:
            return

        while True:
            try:
                await rate_limiter.acquire()
                text = random.choice(ngon)
                await client.send_message(entity, text)
                stats.inc_sent(uid)
                await asyncio.sleep(delay)
            except asyncio.CancelledError:
                break
            except FloodWaitError as e:
                rate_limiter.handle_flood(e.seconds)
                await asyncio.sleep(e.seconds + 1)
            except Exception:
                stats.inc_failed(uid)
                await asyncio.sleep(delay)
    except asyncio.CancelledError:
        pass
    finally:
        try:
            await client.disconnect()
        except Exception:
            pass