"""Thêm ngôn bot chủ."""
import json
from pathlib import Path
from telegram import Update
from telegram.ext import ContextTypes
from utils.permission import admin_only

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
NGON_FILE = DATA_DIR / "ngon.json"

NGON = {"1": {}, "2": {}, "3": {}}
PENDING = {}


def load_ngon():
    if NGON_FILE.exists():
        try:
            return json.loads(NGON_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {"1": {}, "2": {}, "3": {}}
    return {"1": {}, "2": {}, "3": {}}


def save_ngon(data):
    NGON_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


async def _start_add(update, ctx, mode):
    uid = update.effective_user.id
    name = ctx.args[0] if ctx.args else f"set_{mode}_{len(NGON[mode]) + 1}"
    PENDING[uid] = {"mode": mode, "name": name, "lines": []}

    mode_name = {"1": "🎯 /tag", "2": "🎭 /tag2", "3": "🔄 /treongon"}.get(mode, mode)

    await update.message.reply_text(
        f"📎 THÊM NGÔN\n\n"
        f"• Mode: {mode_name}\n"
        f"• Tên: `{name}`\n\n"
        f"Gửi file .txt hoặc text.\n"
        f"Gõ /save để lưu.",
        parse_mode="Markdown"
    )


@admin_only
async def add_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await _start_add(update, ctx, "1")


@admin_only
async def add2_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await _start_add(update, ctx, "2")


@admin_only
async def addtreo_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await _start_add(update, ctx, "3")


async def handle_doc(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid not in PENDING:
        return
    doc = update.message.document
    if not doc or not doc.file_name.endswith(".txt"):
        return
    try:
        f = await doc.get_file()
        data = await f.download_as_bytearray()
        lines = [l.strip() for l in data.decode("utf-8", errors="ignore").splitlines() if l.strip()]
        PENDING[uid]["lines"].extend(lines)
        await update.message.reply_text(
            f"✅ +{len(lines)} dòng. Tổng: {len(PENDING[uid]['lines'])}. Gõ /save."
        )
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {e}")


async def handle_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid not in PENDING:
        return
    text = update.message.text or ""
    if text.startswith("/"):
        return
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    PENDING[uid]["lines"].extend(lines)
    await update.message.reply_text(f"✅ Tổng: {len(PENDING[uid]['lines'])}. Gõ /save.")


async def save_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid not in PENDING:
        await update.message.reply_text("❌ Không có gì để lưu.")
        return
    data = PENDING.pop(uid)
    mode, name, lines = data["mode"], data["name"], data["lines"]
    if not lines:
        await update.message.reply_text("❌ Không có dòng nào.")
        return

    NGON.setdefault(mode, {})[name] = lines
    save_ngon(NGON)

    await update.message.reply_text(
        f"💾 ĐÃ LƯU\n\n"
        f"• Mode: {mode}\n"
        f"• Tên: `{name}`\n"
        f"• Số câu: {len(lines)}",
        parse_mode="Markdown"
    )


@admin_only
async def listngon_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    global NGON
    NGON = load_ngon()

    lines = ["📚 DANH SÁCH NGÔN\n"]
    total = 0
    for mode in ("1", "2", "3"):
        sets = NGON.get(mode, {})
        if not sets:
            continue
        lines.append(f"\nMode {mode}:")
        for name, arr in sets.items():
            lines.append(f"  • `{name}` — {len(arr)} câu")
            total += len(arr)
    lines.append(f"\n📊 Tổng: {total} câu")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


def get_ngon(mode):
    global NGON
    NGON = load_ngon()
    all_lines = []
    for arr in NGON.get(mode, {}).values():
        all_lines.extend(arr)
    return all_lines