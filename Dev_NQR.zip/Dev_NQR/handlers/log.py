"""
/log — Log của mình.
/logall — Log toàn hệ thống (owner).
"""
import time
from telegram import Update
from telegram.ext import ContextTypes
from core.stats import stats
from utils.autodelete import delete_cmd
from utils.helpers import fmt_duration
from config import is_owner


async def log_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id
    s = stats.get(uid)

    if not s:
        await update.message.reply_text(
            "📭 Bạn chưa chạy spam/call lần nào.\n"
            "Dùng `/tag` hoặc `/call` để bắt đầu.",
            parse_mode="Markdown"
        )
        return

    elapsed = time.time() - s["start_time"]
    speed = s["sent"] / elapsed if elapsed > 0 else 0

    await update.message.reply_text(
        f"📊 **THỐNG KÊ**\n\n"
        f"🎯 Tổng mục tiêu: {s['targets']}\n"
        f"📤 Đã gửi: {s['sent']:,}\n"
        f"❌ Thất bại: {s['failed']:,}\n"
        f"⚡ Tốc độ: {speed:.2f} tin/s\n"
        f"⏱️ Thời gian chạy: {fmt_duration(elapsed)}\n"
        f"🔄 Đang xử lý: {'ON' if s['running'] else 'OFF'}",
        parse_mode="Markdown"
    )


async def logall_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not is_owner(uid):
        await update.message.reply_text("👑 Chỉ owner.")
        return

    if not stats.data:
        await update.message.reply_text("📭 Chưa có ai chạy.")
        return

    total_sent = sum(s["sent"] for s in stats.data.values())
    total_failed = sum(s["failed"] for s in stats.data.values())
    running = sum(1 for s in stats.data.values() if s["running"])

    lines = [
        "📊 **THỐNG KÊ TOÀN HỆ THỐNG**\n",
        f"👥 Số user: {len(stats.data)}",
        f"🔄 Đang chạy: {running}",
        f"📤 Tổng gửi: {total_sent:,}",
        f"❌ Tổng lỗi: {total_failed:,}\n",
        "─── Chi tiết ───",
    ]

    sorted_u = sorted(stats.data.items(), key=lambda x: x[1]["sent"], reverse=True)
    for u, s in sorted_u[:20]:
        status = "🟢" if s["running"] else "🔴"
        lines.append(f"{status} `{u}` — {s['sent']:,} tin ({s['failed']} lỗi)")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")