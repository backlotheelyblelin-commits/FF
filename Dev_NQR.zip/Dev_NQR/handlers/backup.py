"""/backup, /restore, /dbcheck, /dblist, /dbclean."""
import shutil
from datetime import datetime
from pathlib import Path
from telegram import Update
from telegram.ext import ContextTypes
from config import OWNER_ID
from database.db import db, DB_PATH
from utils.permission import owner_only
from utils.autodelete import delete_cmd

BASE_DIR = Path(__file__).resolve().parent.parent
BACKUP_DIR = BASE_DIR / "data" / "backups"
BACKUP_DIR.mkdir(parents=True, exist_ok=True)


@owner_only
async def backup_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    if update.effective_chat.type != "private":
        await update.message.reply_text("🚫 Chỉ chat riêng.")
        return
    if not DB_PATH.exists():
        await update.message.reply_text("❌ Chưa có DB.")
        return

    msg = await update.message.reply_text("💾 Đang tạo backup...")
    try:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        bf = BACKUP_DIR / f"bot_{ts}.db"
        shutil.copy2(DB_PATH, bf)
        size_kb = bf.stat().st_size / 1024

        with open(bf, "rb") as f:
            await update.message.reply_document(
                document=f, filename=f"DevNQR_backup_{ts}.db",
                caption=f"💾 **BACKUP**\n• Size: {size_kb:.2f} KB\n• Lúc: {datetime.now()}",
                parse_mode="Markdown"
            )
        await msg.delete()
        db.log(update.effective_user.id, "backup", bf.name)
    except Exception as e:
        await msg.edit_text(f"❌ Lỗi: {e}")


@owner_only
async def restore_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    if update.effective_chat.type != "private":
        return
    if not update.message.reply_to_message or not update.message.reply_to_message.document:
        await update.message.reply_text("📎 Reply file `.db` + `/restore`", parse_mode="Markdown")
        return

    doc = update.message.reply_to_message.document
    if not doc.file_name.endswith(".db"):
        await update.message.reply_text("❌ File .db")
        return

    msg = await update.message.reply_text("⏳ Đang restore...")
    try:
        if DB_PATH.exists():
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            shutil.copy2(DB_PATH, BACKUP_DIR / f"pre_restore_{ts}.db")

        f = await doc.get_file()
        await f.download_to_drive(DB_PATH)

        import sqlite3
        try:
            test = sqlite3.connect(DB_PATH)
            test.execute("SELECT 1 FROM accounts LIMIT 1")
            test.close()
        except Exception as e:
            await msg.edit_text(f"❌ DB hỏng: {e}")
            return

        await msg.edit_text(
            f"✅ **RESTORE OK**\n\n• File: `{doc.file_name}`\n\n⚠️ Restart bot để áp dụng.",
            parse_mode="Markdown"
        )
    except Exception as e:
        await msg.edit_text(f"❌ Lỗi: {e}")


async def dbcheck_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    if update.effective_user.id != OWNER_ID:
        return
    stats = db.get_stats()
    size_mb = db.size_mb()

    lines = [
        "📊 **DATABASE STATUS**\n",
        f"📁 File: `{DB_PATH.name}`",
        f"📏 Size: **{size_mb:.3f} MB**\n",
        "📋 **BẢNG:**",
    ]
    for t, c in stats.items():
        lines.append(f"• {t}: {c}")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def dblist_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    if update.effective_user.id != OWNER_ID:
        return
    files = sorted(BACKUP_DIR.glob("*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not files:
        await update.message.reply_text("📭 Chưa có backup.")
        return
    lines = [f"💾 **DS BACKUP** ({len(files)})\n"]
    for f in files[:20]:
        skb = f.stat().st_size / 1024
        mt = datetime.fromtimestamp(f.stat().st_mtime).strftime("%d/%m %H:%M")
        lines.append(f"• `{f.name}` — {skb:.1f} KB — {mt}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")