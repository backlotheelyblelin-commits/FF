"""Xác minh user CHAT + KÊNH."""
from telegram import Update
from telegram.ext import ContextTypes
from utils.keyboards import btn, build_menu
from utils.verify import check_user_joined, VERIFY_CHATS
from config import is_owner, is_admin


async def require_verify(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    uid = update.effective_user.id
    if is_owner(uid) or is_admin(uid):
        return True

    all_joined, missing = await check_user_joined(ctx.bot, uid)
    if all_joined:
        return True

    await show_verify_menu(update, ctx, missing)
    return False


async def show_verify_menu(update, ctx, missing):
    text = (
        "🔒 **XÁC MINH BẮT BUỘC**\n\n"
        "Bạn cần tham gia **CHAT** và **KÊNH** sau:\n\n"
        "Bấm vào từng nút để tham gia.\n"
        "Sau đó bấm **✅ Đã tham gia** để kiểm tra."
    )
    rows = _build_menu(missing)
    await update.message.reply_text(
        text, parse_mode="Markdown", reply_markup=build_menu(*rows)
    )


def _build_menu(missing):
    rows = []
    for chat in VERIFY_CHATS:
        joined = chat not in missing
        icon = "✅" if joined else chat["icon"]
        rows.append([btn(f"{icon} {chat['name']}", f"verify:join:{chat['name']}")])
    rows.append([btn("✅ Đã tham gia", "verify:check")])
    return rows


async def verify_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid = update.effective_user.id
    parts = query.data.split(":")
    action = parts[1]

    if action == "join":
        name = parts[2]
        chat = next((c for c in VERIFY_CHATS if c["name"] == name), None)
        if chat and chat.get("url"):
            await query.message.reply_text(
                f"{chat['icon']} **{chat['name']}**\n\n"
                f"👉 Tham gia: {chat['url']}\n\n"
                f"Sau khi tham gia, bấm **✅ Đã tham gia**.",
                parse_mode="Markdown",
                disable_web_page_preview=True,
                reply_markup=build_menu([btn("✅ Đã tham gia", "verify:check")])
            )
        return

    if action == "check":
        all_joined, missing = await check_user_joined(ctx.bot, uid)
        if all_joined:
            from database.db import db
            db.set_user_setting(uid, "verified", True)
            await query.edit_message_text(
                "✅ **XÁC MINH THÀNH CÔNG**\n\n"
                "Bạn đã tham gia CHAT và KÊNH.\n"
                "Bấm /start để vào menu.",
                parse_mode="Markdown",
                reply_markup=build_menu([btn("🏠 Menu chính", "main:menu")])
            )
        else:
            missing_names = ", ".join(c["name"] for c in missing)
            await query.answer(f"⚠️ Còn thiếu: {missing_names}", show_alert=True)
            rows = _build_menu(missing)
            await query.edit_message_text(
                f"⚠️ **CHƯA ĐỦ**\n\nCòn thiếu: **{missing_names}**",
                parse_mode="Markdown",
                reply_markup=build_menu(*rows)
            )