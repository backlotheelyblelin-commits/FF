"""/monitor — CPU/RAM."""
from telegram import Update
from telegram.ext import ContextTypes
from utils.permission import owner_only
from utils.autodelete import delete_cmd


@owner_only
async def monitor_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)

    try:
        import psutil
        cpu = psutil.cpu_percent(interval=1)
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage("/")

        text = (
            f"📡 **SYSTEM MONITOR**\n\n"
            f"⚡ **CPU:** {cpu}%\n\n"
            f"🧠 **RAM:**\n"
            f"• Đã dùng: {ram.percent}%\n"
            f"• Còn: {ram.available / 1024**3:.2f} GB\n\n"
            f"💾 **DISK:**\n"
            f"• Đã dùng: {disk.percent}%\n"
            f"• Còn: {disk.free / 1024**3:.2f} GB"
        )
    except ImportError:
        text = "❌ Chưa cài `psutil`.\nChạy: `pip install psutil`"

    await update.message.reply_text(text, parse_mode="Markdown")