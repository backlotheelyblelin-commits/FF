"""User add ngôn riêng cho bot con."""
import asyncio
import json
from pathlib import Path
from datetime import datetime
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from config import OWNER_ID
from bot_manager.security import is_botcon_admin

BOTS_DIR = Path(__file__).resolve().parent.parent / "data" / "bots"
PENDING_DIR = Path(__file__).resolve().parent.parent / "data" / "pending_ngon"


async def addngon_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.bot_data.get("is_botcon", False):
        await update.message.reply_text("⚠️ Chỉ dùng trên bot con.")
        return

    acc_id = ctx.bot_data.get("acc_id")
    uid = update.effective_user.id

    if not is_botcon_admin(acc_id, uid):
        await update.message.reply_text("⛔ Chỉ admin bot con.")
        return

    await update.message.reply_text(
        "📎 **THÊM NGÔN RIÊNG**\n\n"
        "Gửi file .txt (mỗi dòng 1 câu).\n\n"
        "💡 Ngôn sẽ **thay thế** ngôn bot chủ.\n"
        "🔄 Có thể đổi lại bất kỳ lúc nào.\n\n"
        "📤 Gửi file:",
        parse_mode="Markdown"
    )
    ctx.user_data["waiting_ngon"] = acc_id


async def handle_ngon_file(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    acc_id = ctx.user_data.get("waiting_ngon")
    if not acc_id:
        return

    doc = update.message.document
    if not doc or not doc.file_name.endswith(".txt"):
        return

    try:
        f = await doc.get_file()
        data = await f.download_as_bytearray()

        if len(data) > 5 * 1024 * 1024:
            await update.message.reply_text("❌ File quá lớn (max 5MB).")
            return

        text = data.decode("utf-8", errors="ignore")
        lines = [l.strip() for l in text.splitlines() if l.strip()]

        if not lines:
            await update.message.reply_text("❌ File trống.")
            return

        if len(lines) > 5000:
            await update.message.reply_text("❌ Quá nhiều dòng (max 5000).")
            return

    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {e}")
        return

    uid = update.effective_user.id
    set_name = f"user_{uid}"
    bot_dir = BOTS_DIR / f"bot_{acc_id}"
    bot_dir.mkdir(parents=True, exist_ok=True)

    ngon_file = bot_dir / "ngon_user.json"
    if ngon_file.exists():
        try:
            ngon = json.loads(ngon_file.read_text(encoding="utf-8"))
        except Exception:
            ngon = {"1": {}, "2": {}, "3": {}}
    else:
        ngon = {"1": {}, "2": {}, "3": {}}

    ngon.setdefault("1", {})[set_name] = lines
    ngon_file.write_text(json.dumps(ngon, ensure_ascii=False, indent=2), encoding="utf-8")

    # Bật use_custom_ngon
    settings_file = bot_dir / "settings.json"
    if settings_file.exists():
        try:
            settings = json.loads(settings_file.read_text(encoding="utf-8"))
        except Exception:
            settings = {}
    else:
        settings = {}

    settings["use_custom_ngon"] = True
    settings["custom_ngon_set"] = set_name
    settings_file.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")

    await update.message.reply_text(
        f"✅ **ĐÃ THÊM NGÔN**\n\n"
        f"━━━ **THÔNG TIN** ━━━\n"
        f"• Số câu: **{len(lines)}**\n"
        f"• Set: `{set_name}`\n"
        f"• Trạng thái: 🟢 **Xét duyệt thành công**\n"
        f"• Đang dùng: 🟢 **Ngôn riêng của bạn**\n\n"
        f"━━━ **KIỂM DUYỆT** ━━━\n"
        f"📤 File đã được gửi cho owner kiểm duyệt.\n\n"
        f"━━━ **HƯỚNG DẪN** ━━━\n"
        f"💡 Bắt đầu: `/tag @user`\n"
        f"🔄 Đổi về bot chủ: `/resetngon`\n"
        f"📚 Xem ngôn: `/xemngon`",
        parse_mode="Markdown"
    )

    asyncio.create_task(_send_to_owner(ctx, acc_id, uid, lines, data, doc.file_name))
    ctx.user_data.pop("waiting_ngon", None)


async def _send_to_owner(ctx, acc_id, uid, lines, raw_data, original_name):
    try:
        PENDING_DIR.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        save_path = PENDING_DIR / f"ngon_{acc_id}_{uid}_{ts}.txt"
        save_path.write_bytes(raw_data)

        try:
            user = await ctx.bot.get_chat(uid)
            uname = f"@{user.username}" if user.username else user.first_name
        except Exception:
            uname = f"ID {uid}"

        from bot_manager.settings import BotSettings
        s = BotSettings(acc_id).all()

        preview = "\n".join(f"  • {l[:100]}" for l in lines[:5])
        if len(lines) > 5:
            preview += f"\n  _(còn {len(lines) - 5} câu...)_"

        caption = (
            f"📎 **NGÔN MỚI**\n\n"
            f"• User: {uname} (`{uid}`)\n"
            f"• Bot con: `{s.get('bot_name', 'My Bot')}` (#{acc_id})\n"
            f"• File: `{original_name}`\n"
            f"• Số câu: **{len(lines)}**\n\n"
            f"📋 **Preview:**\n{preview}\n\n"
            f"👉 Nếu 18+ → `/xoabotcon {acc_id}`"
        )

        with open(save_path, "rb") as f:
            await ctx.bot.send_document(
                OWNER_ID, document=f, filename=original_name,
                caption=caption[:1024], parse_mode="Markdown"
            )
    except Exception as e:
        print(f"⚠️ Lỗi gửi owner: {e}")


async def xemngon_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.bot_data.get("is_botcon", False):
        return

    acc_id = ctx.bot_data.get("acc_id")
    uid = update.effective_user.id
    set_name = f"user_{uid}"

    bot_dir = BOTS_DIR / f"bot_{acc_id}"
    ngon_file = bot_dir / "ngon_user.json"

    user_lines = []
    if ngon_file.exists():
        try:
            ngon = json.loads(ngon_file.read_text(encoding="utf-8"))
            user_lines = ngon.get("1", {}).get(set_name, [])
        except Exception:
            pass

    if not user_lines:
        await update.message.reply_text(
            "⚠️ **BẠN CHƯA CÓ NGÔN RIÊNG**\n\n"
            "📌 Bot đang dùng ngôn mặc định.\n"
            "📎 Gửi file để thêm ngôn riêng.\n\n"
            "📤 Gửi: `/addngon`",
            parse_mode="Markdown"
        )
        return

    await update.message.reply_text(
        f"📚 **NGÔN CỦA BẠN**\n\n"
        f"• Số câu: **{len(user_lines)}**\n"
        f"• Set: `{set_name}`\n\n"
        f"📎 Đang gửi file...",
        parse_mode="Markdown"
    )

    import io
    content = "\n".join(user_lines)
    file_io = io.BytesIO(content.encode("utf-8"))
    file_io.name = f"ngon_{set_name}.txt"

    await update.message.reply_document(
        document=file_io,
        filename=f"ngon_{set_name}.txt",
        caption=f"📎 Ngôn riêng — {len(user_lines)} câu"
    )


async def resetngon_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.bot_data.get("is_botcon", False):
        return

    acc_id = ctx.bot_data.get("acc_id")
    bot_dir = BOTS_DIR / f"bot_{acc_id}"
    settings_file = bot_dir / "settings.json"

    if settings_file.exists():
        try:
            settings = json.loads(settings_file.read_text(encoding="utf-8"))
        except Exception:
            settings = {}
    else:
        settings = {}

    settings["use_custom_ngon"] = False
    settings_file.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")

    await update.message.reply_text(
        "🔄 **ĐÃ ĐỔI VỀ NGÔN BOT CHỦ**\n\n"
        "• Đang dùng: 🔵 **Ngôn bot chủ**\n\n"
        "💡 Muốn dùng lại ngôn riêng?\n"
        "→ Gửi `/addngon` để thêm.",
        parse_mode="Markdown"
    )