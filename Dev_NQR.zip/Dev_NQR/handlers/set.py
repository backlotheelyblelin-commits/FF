"""
/set <giây> — Delay spam.
/setcall <giây> — Delay call.
"""
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from config import MIN_DELAY, MAX_DELAY
from utils.autodelete import delete_cmd


async def set_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not ctx.args:
        cur = db.get_delay(uid, "spam")
        await update.message.reply_text(
            f"⏱️ Delay spam hiện tại: **{cur}s**\n\n"
            f"Dùng: `/set <giây>`\n"
            f"Min: {MIN_DELAY}s — Max: {MAX_DELAY}s\n"
            f"VD: `/set 0.5`",
            parse_mode="Markdown"
        )
        return

    try:
        val = float(ctx.args[0].replace(",", "."))
    except ValueError:
        await update.message.reply_text("❌ Phải là số. VD: `/set 0.5`", parse_mode="Markdown")
        return

    real = max(MIN_DELAY, min(MAX_DELAY, val))
    db.set_delay(uid, "spam", real)

    note = ""
    if val < MIN_DELAY:
        note = f"\n⚠️ Quá nhỏ → set về min {MIN_DELAY}s"
    elif val > MAX_DELAY:
        note = f"\n⚠️ Quá lớn → set về max {MAX_DELAY}s"

    await update.message.reply_text(
        f"✅ Delay spam = **{real}s**{note}",
        parse_mode="Markdown"
    )


async def setcall_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not ctx.args:
        cur = db.get_delay(uid, "call")
        await update.message.reply_text(
            f"📞 Delay call hiện tại: **{cur}s**\n\n"
            f"Dùng: `/setcall <giây>`\n"
            f"Min: {MIN_DELAY}s — Max: {MAX_DELAY}s",
            parse_mode="Markdown"
        )
        return

    try:
        val = float(ctx.args[0].replace(",", "."))
    except ValueError:
        await update.message.reply_text("❌ Phải là số.")
        return

    real = max(MIN_DELAY, min(MAX_DELAY, val))
    db.set_delay(uid, "call", real)

    note = ""
    if val < MIN_DELAY:
        note = f"\n⚠️ Quá nhỏ → set về min {MIN_DELAY}s"
    elif val > MAX_DELAY:
        note = f"\n⚠️ Quá lớn → set về max {MAX_DELAY}s"

    await update.message.reply_text(
        f"✅ Delay call = **{real}s**{note}",
        parse_mode="Markdown"
    )