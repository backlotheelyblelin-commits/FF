"""/voice — Text → MP3."""
import asyncio
from telegram import Update
from telegram.ext import ContextTypes
from utils.autodelete import delete_cmd
from config import TTS_API_KEY


async def voice_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)

    if not ctx.args:
        await update.message.reply_text("Dùng: `/voice <text>`", parse_mode="Markdown")
        return

    text = " ".join(ctx.args)
    if len(text) > 500:
        await update.message.reply_text("❌ Text quá dài (max 500 ký tự).")
        return

    msg = await update.message.reply_text("🎤 Đang xử lý...")

    try:
        # TODO: Gọi TTS API
        # Placeholder
        await msg.edit_text(
            f"✅ Đã xử lý voice\n\n"
            f"• Text: `{text[:50]}...`\n"
            f"• API: `{TTS_API_KEY[:10]}...`",
            parse_mode="Markdown"
        )
    except Exception as e:
        await msg.edit_text(f"❌ Lỗi: {e}")


async def giong_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    await update.message.reply_text(
        "🔊 **DS GIỌNG HỖ TRỢ**\n\n"
        "• Nữ\n"
        "• Nam\n"
        "• Bé gái\n"
        "• Bé trai",
        parse_mode="Markdown"
    )


async def thay_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)

    if not ctx.args:
        await update.message.reply_text("Dùng: `/thay <tên giọng>`", parse_mode="Markdown")
        return

    giong = " ".join(ctx.args)
    await update.message.reply_text(f"✅ Đã đổi giọng: **{giong}**", parse_mode="Markdown")