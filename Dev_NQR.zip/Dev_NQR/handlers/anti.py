"""/anti on|off."""
from telegram import Update
from telegram.ext import ContextTypes
from core.rate_limiter import rate_limiter
from database.db import db
from utils.autodelete import delete_cmd


async def anti_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not ctx.args:
        status = "🟢 ON" if rate_limiter.enabled else "🔴 OFF"
        await update.message.reply_text(
            f"🛡️ **ANTI RATE-LIMIT**\n\n"
            f"Trạng thái: **{status}**\n"
            f"Delay: {rate_limiter.delay}s",
            parse_mode="Markdown"
        )
        return

    arg = ctx.args[0].lower()
    if arg == "on":
        rate_limiter.enable()
        db.log(uid, "anti_on", "")
        await update.message.reply_text("🛡️ Anti rate-limit: 🟢 **ON**", parse_mode="Markdown")
    elif arg == "off":
        rate_limiter.disable()
        db.log(uid, "anti_off", "")
        await update.message.reply_text("🛡️ Anti rate-limit: 🔴 **OFF**", parse_mode="Markdown")
    else:
        await update.message.reply_text("Dùng: `/anti on|off`", parse_mode="Markdown")