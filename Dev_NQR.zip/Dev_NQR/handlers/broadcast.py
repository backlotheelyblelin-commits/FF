"""/broadcast — Owner gửi hàng loạt."""
import asyncio
from telegram import Update
from telegram.ext import ContextTypes
from config import OWNER_ID
from database.db import db
from utils.permission import owner_only
from utils.autodelete import delete_cmd


def get_all_user_ids() -> list:
    accs = db.get_accounts()
    uids = set()
    for a in accs:
        if a["status"] != "rejected":
            uids.add(a["owner_uid"])
    for a in db.get_all_admins():
        uids.add(a["uid"])
    return sorted(uids)


@owner_only
async def broadcast_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)

    text = ""
    if update.message.reply_to_message:
        replied = update.message.reply_to_message
        text = replied.text or replied.caption or ""
    elif ctx.args:
        text = " ".join(ctx.args)

    if not text:
        await update.message.reply_text("Dùng: `/broadcast <nội dung>`", parse_mode="Markdown")
        return

    users = get_all_user_ids()
    if not users:
        await update.message.reply_text("📭 Không có user.")
        return

    msg = await update.message.reply_text(f"📤 Đang gửi tới **{len(users)}** user...")

    sent, failed = 0, 0
    for uid in users:
        try:
            await ctx.bot.send_message(uid, f"📢 **THÔNG BÁO**\n\n{text}", parse_mode="Markdown")
            sent += 1
        except Exception:
            failed += 1
        await asyncio.sleep(0.05)

    await msg.edit_text(
        f"✅ **XONG**\n\n📤 Thành công: {sent}\n❌ Lỗi: {failed}",
        parse_mode="Markdown"
    )