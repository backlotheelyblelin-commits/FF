"""/checktk — Test acc."""
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from utils.autodelete import delete_cmd


async def checktk_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not ctx.args:
        await update.message.reply_text("Dùng: `/checktk <id>`", parse_mode="Markdown")
        return

    try:
        acc_id = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID phải là số.")
        return

    acc = db.get_account(acc_id)
    if not acc or acc["owner_uid"] != uid:
        await update.message.reply_text("❌ Không tìm thấy acc.")
        return

    msg = await update.message.reply_text(f"🔄 Đang test `{acc['name']}`...")

    try:
        if acc["type"] == "bot":
            from telegram import Bot
            bot = Bot(acc["token"])
            me = await bot.get_me()
            info = f"@{me.username} — {me.first_name}"
        else:
            from telethon import TelegramClient
            from telethon.sessions import StringSession
            client = TelegramClient(
                StringSession(acc["session"]),
                acc["api_id"], acc["api_hash"]
            )
            await client.connect()
            me = await client.get_me()
            info = f"@{me.username}" if me.username else me.first_name
            await client.disconnect()

        await msg.edit_text(
            f"✅ **ACC SỐNG**\n\n"
            f"• Tên: `{acc['name']}`\n"
            f"• Info: {info}",
            parse_mode="Markdown"
        )
    except Exception as e:
        await msg.edit_text(
            f"❌ **ACC DIE**\n\n"
            f"• Tên: `{acc['name']}`\n"
            f"• Lỗi: `{str(e)[:100]}`",
            parse_mode="Markdown"
        )