"""Menu /start."""
from telegram import Update
from telegram.ext import ContextTypes
from utils.keyboards import build_menu
from utils.autodelete import delete_cmd
from utils.i18n import t
from utils.menu_builder import get_menu_rows, get_start_text


async def start_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id
    is_botcon = ctx.bot_data.get("is_botcon", False)
    acc_id = ctx.bot_data.get("acc_id")

    bot_name = emoji = custom_text = footer = None
    if is_botcon and acc_id:
        from bot_manager.settings import BotSettings
        s = BotSettings(acc_id).all()
        bot_name = s.get("bot_name")
        emoji = s.get("emoji")
        custom_text = s.get("start_text")
        footer = s.get("footer")

    text = get_start_text(uid, is_botcon, bot_name, emoji, custom_text, footer)
    rows = get_menu_rows(uid, is_botcon)

    await update.message.reply_text(
        text, parse_mode="Markdown", reply_markup=build_menu(*rows)
    )


async def main_menu_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid = update.effective_user.id
    is_botcon = ctx.bot_data.get("is_botcon", False)
    acc_id = ctx.bot_data.get("acc_id")

    bot_name = emoji = custom_text = footer = None
    if is_botcon and acc_id:
        from bot_manager.settings import BotSettings
        s = BotSettings(acc_id).all()
        bot_name = s.get("bot_name")
        emoji = s.get("emoji")
        custom_text = s.get("start_text")
        footer = s.get("footer")

    text = get_start_text(uid, is_botcon, bot_name, emoji, custom_text, footer)
    rows = get_menu_rows(uid, is_botcon)

    await query.edit_message_text(
        text, parse_mode="Markdown", reply_markup=build_menu(*rows)
    )