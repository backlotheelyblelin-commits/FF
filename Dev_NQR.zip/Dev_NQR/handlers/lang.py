"""/lang — Đổi ngôn ngữ."""
from telegram import Update
from telegram.ext import ContextTypes
from utils.keyboards import btn, build_menu
from utils.i18n import get_lang, set_lang
from utils.autodelete import delete_cmd


async def lang_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id
    cur = get_lang(uid)

    text = (
        "🌐 **NGÔN NGỮ / LANGUAGE**\n\n"
        f"Hiện tại: **{'🇻🇳 Tiếng Việt' if cur == 'vi' else '🇬🇧 English'}**"
    )

    kb = build_menu(
        [btn("🇻🇳 Tiếng Việt", "lang:vi")],
        [btn("🇬🇧 English", "lang:en")],
    )

    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=kb)


async def lang_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid = update.effective_user.id
    lang = query.data.split(":")[1]

    if set_lang(uid, lang):
        if lang == "vi":
            text = "✅ Đã đổi sang **Tiếng Việt**"
        else:
            text = "✅ Language: **English**"
        await query.edit_message_text(text, parse_mode="Markdown")
    else:
        await query.answer("❌ Lỗi", show_alert=True)