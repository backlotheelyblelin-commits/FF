"""/sl — Menu cấu hình bot chủ."""
from telegram import Update
from telegram.ext import ContextTypes
from utils.keyboards import btn, build_menu
from utils.permission import owner_only
from handlers.sl_sections import SECTIONS
from utils.autodelete import delete_cmd


SL_TEXT = """╭━━━ ⚙️ CUSTOM CENTER ━━━╮
┃
┃ Chọn mục để cấu hình
┃
╰━━━━━━━━━━━━━━━━━━━━╯"""


def sl_keyboard():
    rows = [
        [btn("🎨 1. Giao diện", "sl:1"), btn("📝 2. Tin nhắn", "sl:2")],
        [btn("📋 3. Menu", "sl:3"), btn("📊 4. Log", "sl:4")],
        [btn("⏱️ 5. Tốc độ", "sl:5"), btn("📦 6. Queue", "sl:6")],
        [btn("🔊 7. Voice", "sl:7"), btn("👤 8. Tài khoản", "sl:8")],
        [btn("👮 9. Admin", "sl:9"), btn("🔔 10. Thông báo", "sl:10")],
        [btn("💾 11. Database", "sl:11")],
        [btn("🚨 21. Alert", "sl:21"), btn("🔑 22. API", "sl:22")],
        [btn("🧪 23. Test", "sl:23"), btn("👥 24. User", "sl:24")],
        [btn("♻️ 25. Version", "sl:25"), btn("🛡️ 26. Anti-spam", "sl:26")],
        [btn("📡 27. Monitoring", "sl:27"), btn("🗃️ 28. Data", "sl:28")],
        [btn("🧹 30. Cleanup", "sl:30"), btn("🔄 31. Update", "sl:31")],
        [btn("⏰ 32. Time", "sl:32"), btn("📈 33. Analytics", "sl:33")],
        [btn("🧰 34. Toolbox", "sl:34"), btn("🔒 35. Privacy", "sl:35")],
        [btn("❌ Đóng", "sl:close")],
    ]
    return build_menu(*rows)


@owner_only
async def sl_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    await update.message.reply_text(SL_TEXT, reply_markup=sl_keyboard())


async def sl_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    from config import is_owner
    if not is_owner(update.effective_user.id):
        return

    data = query.data

    if data == "sl:close":
        try:
            await query.message.delete()
        except Exception:
            pass
        return

    if data in ("sl:back", "sl:main"):
        await query.edit_message_text(SL_TEXT, reply_markup=sl_keyboard())
        return

    parts = data.split(":")
    if len(parts) < 2:
        return

    section = parts[1]
    info = SECTIONS.get(section)
    if not info:
        await query.edit_message_text("❌ Mục không tồn tại.")
        return

    name, items = info
    rows = [[btn(f"{i}. {item}", f"sl:{section}:{i}")]
            for i, item in enumerate(items, 1)]
    rows.append([btn("🔙 Quay lại", "sl:back")])

    await query.edit_message_text(
        f"{name}\n\nChọn mục:",
        reply_markup=build_menu(*rows)
    )