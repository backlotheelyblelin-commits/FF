"""
/tag2 — Tag ẩn (không hiện @).
"""
import asyncio
import random
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from core.queue_manager import queue_manager
from core.rate_limiter import rate_limiter
from core.stats import stats
from utils.autodelete import delete_cmd


async def tag2_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    target = _get_target(update, ctx)
    if not target:
        await update.message.reply_text(
            "📌 Dùng: `/tag2 @user`\n"
            "Hoặc reply tin user + `/tag2`",
            parse_mode="Markdown"
        )
        return

    acc = db.get_default_account(uid)
    if not acc:
        await update.message.reply_text("⚠️ Chưa có acc. Dùng /addtk.")
        return

    # Lấy ngôn mode 2
    is_botcon = ctx.bot_data.get("is_botcon", False)
    if is_botcon:
        acc_id = ctx.bot_data.get("acc_id")
        from utils.ngon_loader import get_ngon_for_botcon
        ngon = get_ngon_for_botcon(acc_id, "2")
    else:
        from handlers.add import get_ngon
        ngon = get_ngon("2")

    if not ngon:
        await update.message.reply_text("❌ Chưa có ngôn cho /tag2.")
        return

    delay = db.get_delay(uid, "spam")

    if queue_manager.is_running(uid, "spam"):
        queue_manager.stop_user(uid)

    task = asyncio.create_task(_tag2_worker(ctx, uid, target, acc, ngon, delay))
    queue_manager.register(uid, task, kind="spam")

    acc_type = "🤖 Bot Token" if acc["type"] == "bot" else "👤 User Session"

    await update.message.reply_text(
        f"🎭 **BẮT ĐẦU TAG ẨN**\n\n"
        f"━━━ **THÔNG TIN** ━━━\n"
        f"• Target: `{target}`\n"
        f"• Acc: {acc_type}\n"
        f"• Delay: {delay}s\n"
        f"• Ngôn: {len(ngon)} câu\n\n"
        f"━━━ **ĐANG CHẠY** ━━━\n"
        f"🟢 Tag ẩn: ON\n\n"
        f"💡 **Tắt:** `/off`",
        parse_mode="Markdown"
    )


def _get_target(update, ctx):
    if update.message.reply_to_message:
        return update.message.reply_to_message.from_user.id
    if ctx.args:
        arg = ctx.args[0]
        if arg.startswith("@"):
            return arg
        try:
            return int(arg)
        except ValueError:
            return None
    return None


async def _tag2_worker(ctx, uid, target, acc, ngon, delay):
    if acc["type"] == "bot":
        await _tag2_via_bot(ctx, uid, target, acc, ngon, delay)
    else:
        await _tag2_via_session(ctx, uid, target, acc, ngon, delay)


async def _tag2_via_bot(ctx, uid, target, acc, ngon, delay):
    from telegram import Bot
    from telegram.error import TelegramError, RetryAfter

    bot = Bot(token=acc["token"])
    stats.start(uid, targets=1)

    try:
        while True:
            try:
                await rate_limiter.acquire()
                text = random.choice(ngon)

                # Tag ẩn — dùng HTML link
                if isinstance(target, str) and target.startswith("@"):
                    # Không tag được ẩn với username → dùng text bình thường
                    msg = f'<a href="https://t.me/{target[1:]}">{text}</a>'
                    chat_id = target
                else:
                    msg = f'<a href="tg://user?id={target}">{text}</a>'
                    chat_id = target

                await bot.send_message(
                    chat_id, msg,
                    parse_mode="HTML",
                    disable_web_page_preview=True
                )
                stats.inc_sent(uid)
                await asyncio.sleep(delay)

            except asyncio.CancelledError:
                break
            except RetryAfter as e:
                rate_limiter.handle_flood(e.retry_after)
                await asyncio.sleep(e.retry_after + 1)
            except TelegramError:
                stats.inc_failed(uid)
                await asyncio.sleep(delay)
    except asyncio.CancelledError:
        pass
    finally:
        stats.stop(uid)


async def _tag2_via_session(ctx, uid, target, acc, ngon, delay):
    from telethon import TelegramClient
    from telethon.sessions import StringSession
    from telethon.tl.functions.messages import SendMessageRequest
    from telethon.errors import FloodWaitError

    client = TelegramClient(
        StringSession(acc["session"]),
        acc["api_id"], acc["api_hash"]
    )

    stats.start(uid, targets=1)

    try:
        await client.connect()
        if not await client.is_user_authorized():
            return

        try:
            entity = await client.get_entity(target)
        except Exception:
            return

        while True:
            try:
                await rate_limiter.acquire()
                text = random.choice(ngon)

                # Tag ẩn với HTML
                html = f'<a href="tg://user?id={target}">{text}</a>'

                await client.send_message(entity, html, parse_mode="html")
                stats.inc_sent(uid)
                await asyncio.sleep(delay)

            except asyncio.CancelledError:
                break
            except FloodWaitError as e:
                rate_limiter.handle_flood(e.seconds)
                await asyncio.sleep(e.seconds + 1)
            except Exception:
                stats.inc_failed(uid)
                await asyncio.sleep(delay)
    except asyncio.CancelledError:
        pass
    finally:
        try:
            await client.disconnect()
        except Exception:
            pass