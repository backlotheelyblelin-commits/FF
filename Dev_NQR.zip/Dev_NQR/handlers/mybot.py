"""/mybot — Quản lý bot con."""
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from utils.keyboards import btn, build_menu
from utils.autodelete import delete_cmd
from config import is_owner


def _is_botcon(ctx) -> bool:
    return ctx.bot_data.get("is_botcon", False) if ctx else False


async def mybot_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)

    if _is_botcon(ctx):
        await update.message.reply_text("⛔ Bot con không có bot con.")
        return

    await show_my_bots(update.message.reply_text, update.effective_user.id)


async def show_my_bots(reply, uid: int):
    bots = [a for a in db.get_accounts(owner_uid=uid) if a["type"] == "bot"]

    if not bots:
        rows = []
        if is_owner(uid):
            rows.append([btn("👥 Xem TẤT CẢ", "mybot:all")])
        rows.append([btn("➕ Thêm bot con", "addtk:start")])
        rows.append([btn("🔙 Quay lại", "main:menu")])

        await reply(
            "📭 Bạn chưa có bot con nào.\nDùng /addtk → Bot Token để tạo.",
            reply_markup=build_menu(*rows)
        )
        return

    from bot_manager.manager import is_running

    rows = []
    for b in bots:
        status = "🟢" if is_running(b["id"]) else "🔴"
        rows.append([btn(f"{status} {b['name']} #{b['id']}", f"mybot:view:{b['id']}")])

    rows.append([btn("➕ Thêm bot con", "addtk:start")])
    if is_owner(uid):
        rows.append([btn("👥 Xem TẤT CẢ", "mybot:all")])
    rows.append([btn("🔙 Quay lại", "main:menu")])

    await reply(
        f"🤖 **BOT CON CỦA BẠN** ({len(bots)})\n\nChọn bot:",
        parse_mode="Markdown",
        reply_markup=build_menu(*rows)
    )


async def mybot_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uid = update.effective_user.id
    parts = query.data.split(":")
    action = parts[1]

    if action == "list":
        await show_my_bots(query.edit_message_text, uid)
        return

    if action == "all":
        if not is_owner(uid):
            await query.answer("👑 Chỉ owner.", show_alert=True)
            return
        await show_all_bots(query)
        return

    if action == "view":
        acc_id = int(parts[2])
        await _show_detail(query, acc_id, uid)
        return

    if action == "start":
        acc_id = int(parts[2])
        acc = db.get_account(acc_id)
        if not acc or acc["owner_uid"] != uid:
            return
        from bot_manager.manager import start_bot
        ok = await start_bot(acc_id)
        await query.answer("▶️ Đã bật!" if ok else "⚠️ Đang chạy/lỗi", show_alert=True)
        await _show_detail(query, acc_id, uid)
        return

    if action == "stop":
        acc_id = int(parts[2])
        acc = db.get_account(acc_id)
        if not acc or acc["owner_uid"] != uid:
            return
        from bot_manager.manager import stop_bot
        await stop_bot(acc_id)
        await query.answer("⏹️ Đã dừng!", show_alert=True)
        await _show_detail(query, acc_id, uid)
        return

    if action == "del":
        acc_id = int(parts[2])
        acc = db.get_account(acc_id)
        if not acc or acc["owner_uid"] != uid:
            return
        from bot_manager.manager import stop_bot
        await stop_bot(acc_id)
        db.delete_account(acc_id, owner_uid=uid)
        await query.answer("🗑️ Đã xóa!", show_alert=True)
        await show_my_bots(query.edit_message_text, uid)
        return


async def _show_detail(query, acc_id: int, uid: int):
    acc = db.get_account(acc_id)
    if not acc or acc["owner_uid"] != uid:
        await query.answer("❌ Không phải bot của bạn.", show_alert=True)
        return

    from bot_manager.manager import is_running
    from bot_manager.settings import BotSettings

    s = BotSettings(acc_id).all()
    running = is_running(acc_id)
    status = "🟢 Đang chạy" if running else "🔴 Đã dừng"

    text = (
        f"🤖 **BOT: {s.get('bot_name', 'My Bot')}**\n\n"
        f"• ID: `{acc_id}`\n"
        f"• Trạng thái: {status}\n"
        f"• Ngôn ngữ: {'🇻🇳 Việt' if s.get('language') == 'vi' else '🇬🇧 Anh'}\n"
        f"• Delay: {s.get('delay_default')}s"
    )

    rows = [
        [btn("▶️ Bật", f"mybot:start:{acc_id}"),
         btn("⏹️ Dừng", f"mybot:stop:{acc_id}")],
        [btn("🎨 Cấu hình", f"bot:config:{acc_id}")],
        [btn("📚 Ngôn riêng", f"bot:ngon:{acc_id}")],
        [btn("🗑️ Xóa bot", f"mybot:del:{acc_id}")],
        [btn("🔙 Quay lại", "mybot:list")],
    ]

    await query.edit_message_text(text, parse_mode="Markdown", reply_markup=build_menu(*rows))


async def show_all_bots(query):
    """Owner xem toàn bộ bot con."""
    all_bots = [a for a in db.get_accounts() if a["type"] == "bot"]

    if not all_bots:
        await query.edit_message_text(
            "📭 Chưa có bot con nào.",
            reply_markup=build_menu([btn("🔙 Quay lại", "mybot:list")])
        )
        return

    by_user = {}
    for b in all_bots:
        by_user.setdefault(b["owner_uid"], []).append(b)

    rows = []
    for owner_uid, bots in by_user.items():
        rows.append([btn(
            f"👤 User {owner_uid} ({len(bots)} bot)",
            f"mybot:byuser:{owner_uid}"
        )])

    rows.append([btn("🔙 Quay lại", "mybot:list")])

    await query.edit_message_text(
        f"👥 **TOÀN BỘ BOT CON**\n\n"
        f"• Tổng: {len(all_bots)}\n"
        f"• User có bot: {len(by_user)}",
        parse_mode="Markdown",
        reply_markup=build_menu(*rows)
    )