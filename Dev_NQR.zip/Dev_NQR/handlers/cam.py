"""/cam — Cam group."""
import asyncio
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from core.queue_manager import queue_manager
from utils.autodelete import delete_cmd


async def cam_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if len(ctx.args) < 2:
        await update.message.reply_text(
            "📌 Dùng: `/cam <uid> <cid>`\nVD: `/cam 123456789 -1001234567890`",
            parse_mode="Markdown"
        )
        return

    try:
        target_uid = int(ctx.args[0])
        target_cid = int(ctx.args[1])
    except ValueError:
        await update.message.reply_text("❌ UID/CID phải là số.")
        return

    acc = db.get_default_account(uid)
    if not acc:
        await update.message.reply_text("⚠️ Chưa có acc.")
        return

    if acc["type"] == "bot":
        from utils.bot_admin import check_bot_admin
        is_admin, reason = await check_bot_admin(acc["token"], target_cid)
        if not is_admin:
            await update.message.reply_text(
                f"⚠️ Bot Token không xóa được tin.\n\nLý do: {reason}\n\n💡 Cần admin group hoặc dùng User Session.",
                parse_mode="Markdown"
            )
            return
        db.add_cam(uid, target_uid, target_cid)
        task = asyncio.create_task(_cam_via_bot(ctx, uid, target_uid, target_cid, acc))
        queue_manager.register(uid, task, kind="cam")
        await update.message.reply_text(
            f"🗑️ **ĐÃ BẬT CAM**\n\n• User: `{target_uid}`\n• Group: `{target_cid}`\n• Cách: 🤖 Bot admin\n\n💡 Tắt: `/sua {target_uid} {target_cid}`",
            parse_mode="Markdown"
        )
    else:
        db.add_cam(uid, target_uid, target_cid)
        task = asyncio.create_task(_cam_via_session(ctx, uid, target_uid, target_cid, acc))
        queue_manager.register(uid, task, kind="cam")
        await update.message.reply_text(
            f"🗑️ **ĐÃ BẬT CAM**\n\n• User: `{target_uid}`\n• Group: `{target_cid}`\n• Cách: 👤 User Session\n\n💡 Tắt: `/sua {target_uid} {target_cid}`",
            parse_mode="Markdown"
        )


async def _cam_via_session(ctx, uid, target_uid, target_cid, acc):
    from telethon import TelegramClient, events
    from telethon.sessions import StringSession
    client = TelegramClient(StringSession(acc["session"]), acc["api_id"], acc["api_hash"])
    try:
        await client.connect()
        if not await client.is_user_authorized():
            return

        @client.on(events.NewMessage(chats=[target_cid]))
        async def handler(event):
            try:
                sender = await event.get_sender()
                if sender and sender.id == target_uid:
                    await event.delete()
            except Exception:
                pass

        await client.run_until_disconnected()
    except asyncio.CancelledError:
        pass
    finally:
        try:
            await client.disconnect()
        except Exception:
            pass


async def _cam_via_bot(ctx, uid, target_uid, target_cid, acc):
    from telegram import Bot
    from telegram.ext import ApplicationBuilder, MessageHandler, filters
    app = ApplicationBuilder().token(acc["token"]).build()

    async def handler(update, ctx2):
        if not update.message:
            return
        sender = update.effective_user.id if update.effective_user else 0
        if sender != target_uid:
            return
        try:
            await update.message.delete()
        except Exception:
            pass

    app.add_handler(MessageHandler(filters.Chat(chat_id=target_cid) & filters.ALL, handler))

    try:
        await app.initialize()
        await app.start()
        await app.updater.start_polling()
        while True:
            await asyncio.sleep(3600)
    except asyncio.CancelledError:
        pass
    finally:
        try:
            await app.updater.stop()
            await app.stop()
            await app.shutdown()
        except Exception:
            pass