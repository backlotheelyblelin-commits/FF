"""/setadmin, /deladmin, /listadmin."""
from telegram import Update
from telegram.ext import ContextTypes
from config import OWNER_ID
from database.db import db
from utils.permission import owner_only
from utils.autodelete import delete_cmd


@owner_only
async def setadmin_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)

    target = None
    if update.message.reply_to_message:
        target = update.message.reply_to_message.from_user.id
    elif ctx.args:
        try:
            target = int(ctx.args[0])
        except ValueError:
            await update.message.reply_text("❌ ID phải là số.")
            return
    else:
        await update.message.reply_text("Dùng: `/setadmin <id>`", parse_mode="Markdown")
        return

    if target == OWNER_ID:
        await update.message.reply_text("⚠️ Owner rồi.")
        return

    if db.is_admin(target):
        await update.message.reply_text(f"⚠️ Đã là admin.")
        return

    db.add_admin(target, by=update.effective_user.id)
    db.log(update.effective_user.id, "add_admin", str(target))

    await update.message.reply_text(f"✅ Đã thêm admin `{target}`", parse_mode="Markdown")

    try:
        await ctx.bot.send_message(target, "🎉 Bạn đã được cấp quyền **ADMIN**!", parse_mode="Markdown")
    except Exception:
        pass


@owner_only
async def deladmin_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)

    if not ctx.args:
        await update.message.reply_text("Dùng: `/deladmin <id>`", parse_mode="Markdown")
        return

    try:
        target = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID phải là số.")
        return

    if not db.is_admin(target):
        await update.message.reply_text(f"⚠️ Không phải admin.")
        return

    db.remove_admin(target)
    await update.message.reply_text(f"🗑️ Đã xóa admin `{target}`", parse_mode="Markdown")

    try:
        await ctx.bot.send_message(target, "⚠️ Bạn đã bị thu hồi quyền ADMIN.", parse_mode="Markdown")
    except Exception:
        pass


async def listadmin_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)

    admins = db.get_all_admins()
    lines = [f"👑 **OWNER**: `{OWNER_ID}`\n"]

    if not admins:
        lines.append("👮 **ADMIN**: _(chưa có)_")
    else:
        lines.append(f"👮 **ADMIN** ({len(admins)}):")
        for a in admins:
            try:
                user = await ctx.bot.get_chat(a["uid"])
                info = f"@{user.username}" if user.username else user.first_name
            except Exception:
                info = "❓"
            lines.append(f"• `{a['uid']}` — {info}")

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")