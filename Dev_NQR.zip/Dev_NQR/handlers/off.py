"""
/off — Chỉ tắt spam/call/treongon của mình.
/offall — Owner tắt toàn bộ.
"""
from telegram import Update
from telegram.ext import ContextTypes
from config import is_owner
from core.queue_manager import queue_manager
from database.db import db
from utils.autodelete import delete_cmd


async def off_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    queue_manager.stop_spam_user(uid)
    db.set_state(uid, spam_on=0, call_on=0, treongon_on=0)
    db.log(uid, "off", "")

    await update.message.reply_text(
        "🔴 **ĐÃ DỪNG**\n\n"
        "━━━ **TRẠNG THÁI** ━━━\n"
        "• Spam/Tag: 🔴 OFF\n"
        "• Call: 🔴 OFF\n"
        "• Treo ngôn: 🔴 OFF\n\n"
        "💡 Bật lại:\n"
        "• `/tag @user`\n"
        "• `/call <id>`\n"
        "• `/treongon on`\n\n"
        "⚠️ `/im` và `/cam` vẫn chạy.\n"
        "Tắt bằng `/noi` hoặc `/sua`.",
        parse_mode="Markdown"
    )


async def offall_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not is_owner(uid):
        await update.message.reply_text("👑 Chỉ chủ bot.")
        return

    queue_manager.stop_all()
    db.log(uid, "offall", "")

    await update.message.reply_text(
        "🔴 **[OWNER] ĐÃ DỪNG TOÀN BỘ**\n\n"
        "• Tất cả spam/call/treongon\n"
        "• Tất cả im/cam",
        parse_mode="Markdown"
    )