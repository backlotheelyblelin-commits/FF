"""
/status — Trạng thái của mình.
/globalstatus — Toàn hệ thống (admin+).
"""
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from core.queue_manager import queue_manager
from utils.autodelete import delete_cmd
from config import is_admin, is_owner


async def status_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    state = db.get_state(uid)
    spam_on = state.get("spam_on", 0)
    call_on = state.get("call_on", 0)
    treo_on = state.get("treongon_on", 0)

    await update.message.reply_text(
        f"📊 **TRẠNG THÁI CỦA BẠN**\n\n"
        f"🚀 Spam/Tag: {'🟢 ON' if spam_on else '🔴 OFF'}\n"
        f"📞 Call: {'🟢 ON' if call_on else '🔴 OFF'}\n"
        f"🔄 Treo ngôn: {'🟢 ON' if treo_on else '🔴 OFF'}\n"
        f"⚙️ Queue: {'🟢 RUNNING' if queue_manager.is_running(uid) else '🔴 IDLE'}",
        parse_mode="Markdown"
    )


async def globalstatus_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not is_admin(uid):
        await update.message.reply_text("👮 Chỉ admin bot.")
        return

    total = queue_manager.count_running()
    users = queue_manager.running_users()

    text = (
        f"📡 **TRẠNG THÁI TOÀN HỆ THỐNG**\n\n"
        f"🚀 Task đang chạy: **{total}**\n"
        f"👥 User đang hoạt động: **{len(users)}**\n"
    )

    if is_owner(uid) and users:
        text += "\n─── User IDs ───\n"
        for u in users[:20]:
            text += f"• `{u}`\n"

    await update.message.reply_text(text, parse_mode="Markdown")