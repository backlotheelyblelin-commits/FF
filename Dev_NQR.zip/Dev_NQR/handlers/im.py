"""/im — Xóa tin chat riêng liên tục."""
import asyncio
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from core.queue_manager import queue_manager
from utils.autodelete import delete_cmd


async def im_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not ctx.args:
        await update.message.reply_text("Dùng: `/im <uid>`", parse_mode="Markdown")
        return

    try:
        target = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ UID phải là số.")
        return

    acc = db.get_default_account(uid)
    if not acc:
        await update.message.reply_text("⚠️ Chưa có acc.")
        return

    if acc["type"] == "bot":
        await update.message.reply_text(
            "⚠️ **Bot Token KHÔNG im được.**\n\n"
            "• Telegram cấm bot xóa tin user chat riêng.\n\n"
            "💡 Cần User Session:\n"
            "👉 `/addtk` → User Session",
            parse_mode="Markdown"
        )
        return

    db.block_user(uid, target)
    task = asyncio.create_task(_im_worker(ctx, uid, target, acc))
    queue_manager.register(uid, task, kind="im")
    db.log(uid, "im", str(target))

    await update.message.reply_text(
        f"🗑️ **ĐÃ BẬT XÓA TIN**\n\n"
        f"• User: `{target}`\n"
        f"• Chat: riêng\n"
        f"• Cách: 👤 User session\n"
        f"• Tốc độ: ⚡⚡ Siêu nhanh\n\n"
        f"💡 Tắt: `/noi {target}`",
        parse_mode="Markdown"
    )


async def _im_worker(ctx, uid, target, acc):
    from telethon import TelegramClient, events
    from telethon.sessions import StringSession

    client = TelegramClient(
        StringSession(acc["session"]),
        acc["api_id"], acc["api_hash"]
    )

    try:
        await client.connect()
        if not await client.is_user_authorized():
            return

        @client.on(events.NewMessage(incoming=True))
        async def handler(event):
            try:
                sender = await event.get_sender()
                if sender and sender.id == target:
                    await event.delete()
            except Exception:
                pass

        await client.run_until_disconnected()
    except asyncio.CancelledError:
        pass
    finally:
        try:
            await client.disconnect()
        except Exception:
            pass