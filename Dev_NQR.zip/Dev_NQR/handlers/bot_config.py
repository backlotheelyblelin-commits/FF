"""Config bot con."""
import json
from pathlib import Path
from telegram import Update
from telegram.ext import ContextTypes
from utils.keyboards import btn, build_menu
from utils.autodelete import delete_cmd
from bot_manager.security import is_botcon_admin

BOTS_DIR = Path(__file__).resolve().parent.parent / "data" / "bots"


async def bot_config_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    uid = update.effective_user.id
    acc_id = ctx.bot_data.get("acc_id")

    if not acc_id:
        await query.answer("❌ Không xác định bot.", show_alert=True)
        return

    if not is_botcon_admin(acc_id, uid):
        await query.answer("⛔ Chỉ admin bot con.", show_alert=True)
        return

    data = query.data

    if data.startswith("bot:config"):
        await _show_config(query, acc_id)
        return

    parts = data.split(":")

    if parts[1] == "set":
        key = parts[2]
        ctx.user_data["pending_set"] = {"acc_id": acc_id, "key": key}
        await query.edit_message_text(f"✏️ Gửi giá trị mới cho **{key}**:", parse_mode="Markdown")
        return

    if parts[1] == "toggle":
        key = parts[2]
        from bot_manager.settings import BotSettings
        s = BotSettings(acc_id)
        s.set(key, not s.get(key, False))
        await _show_config(query, acc_id)
        return


async def _show_config(query, acc_id: int):
    from bot_manager.settings import BotSettings
    from bot_manager.manager import is_running

    s = BotSettings(acc_id).all()
    running = is_running(acc_id)
    status = "🟢 Đang chạy" if running else "🔴 Đã dừng"

    text = (
        f"⚙️ **CẤU HÌNH BOT #{acc_id}**\n\n"
        f"━━━ ĐIỀU KHIỂN ━━━\n"
        f"• Trạng thái: {status}\n\n"
        f"━━━ THÔNG TIN ━━━\n"
        f"• Tên: `{s['bot_name']}`\n"
        f"• Emoji: {s['emoji']}\n"
        f"• Footer: `{s['footer'] or '(trống)'}`\n\n"
        f"━━━ CÀI ĐẶT ━━━\n"
        f"• Ngôn ngữ: {'🇻🇳 Việt' if s['language'] == 'vi' else '🇬🇧 Anh'}\n"
        f"• Delay: {s['delay_default']}s\n"
        f"• Prefix: `{s['prefix']}`\n"
        f"• Anti-flood: {'🟢 ON' if s['anti_flood'] else '🔴 OFF'}\n"
        f"• Auto-delete: {'🟢 ON' if s['auto_delete'] else '🔴 OFF'}"
    )

    kb = build_menu(
        [btn("▶️ Bật", f"mybot:start:{acc_id}"),
         btn("⏹️ Dừng", f"mybot:stop:{acc_id}")],
        [btn("1. 📛 Tên bot", f"bot:set:bot_name"),
         btn("2. 😀 Emoji", f"bot:set:emoji")],
        [btn("3. ✍️ Footer", f"bot:set:footer")],
        [btn("4. 💬 Tin /start", f"bot:set:start_text")],
        [btn("5. 💬 Tin /help", f"bot:set:help_text")],
        [btn("6. 🌐 Ngôn ngữ", f"bot:set:language")],
        [btn("7. ⏱️ Delay", f"bot:set:delay_default")],
        [btn("8. 🔤 Prefix", f"bot:set:prefix")],
        [btn("9. 🛡️ Anti-flood", f"bot:toggle:anti_flood")],
        [btn("10. 🗑️ Auto-delete", f"bot:toggle:auto_delete")],
        [btn("🔙 Quay lại", "main:menu")],
    )

    await query.edit_message_text(text, parse_mode="Markdown", reply_markup=kb)


async def bot_set_input(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Nhận giá trị user nhập."""
    pending = ctx.user_data.get("pending_set")
    if not pending:
        return

    acc_id = pending["acc_id"]
    key = pending["key"]
    uid = update.effective_user.id

    if not is_botcon_admin(acc_id, uid):
        ctx.user_data.pop("pending_set", None)
        return

    value = update.message.text.strip()

    if key == "delay_default":
        try:
            value = float(value.replace(",", "."))
            if not (0.1 <= value <= 3600):
                raise ValueError
        except ValueError:
            await update.message.reply_text("❌ Delay 0.1 - 3600")
            return

    if key == "language" and value not in ("vi", "en"):
        await update.message.reply_text("❌ Chỉ 'vi' hoặc 'en'")
        return

    from bot_manager.settings import BotSettings
    s = BotSettings(acc_id)
    s.set(key, value)
    ctx.user_data.pop("pending_set", None)

    await update.message.reply_text(
        f"✅ Đã cập nhật `{key}` = `{value}`",
        parse_mode="Markdown"
    )