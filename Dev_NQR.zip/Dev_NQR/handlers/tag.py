"""
/tag — Spam + tag.
"""
import asyncio
import random
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from core.queue_manager import queue_manager
from core.rate_limiter import rate_limiter
from core.stats import stats
from utils.autodelete import delete_cmd


async def tag_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    target = _get_target(update, ctx)
    if not target:
        await update.message.reply_text(
            "📌 Dùng: `/tag @user`\n"
            "Hoặc reply tin user + `/tag`",
            parse_mode="Markdown"
        )
        return

    acc = db.get_default_account(uid)
    if not acc:
        await update.message.reply_text("⚠️ Chưa có acc. Dùng /addtk.")
        return

    # Lấy ngôn
    is_botcon = ctx.bot_data.get("is_botcon", False)
    if is_botcon:
        acc_id = ctx.bot_data.get("acc_id")
        from utils.ngon_loader import get_ngon_for_botcon
        ngon = get_ngon_for_botcon(acc_id, "1")
    else:
        from handlers.add import get_ngon
        ngon = get_ngon("1")

    if not ngon:
        await update.message.reply_text("❌ Chưa có ngôn.")
        return

    delay = db.get_delay(uid, "spam")

    if queue_manager.is_running(uid, "spam"):
        queue_manager.stop_user(uid)

    task = asyncio.create_task(_tag_worker(ctx, uid, target, acc, ngon, delay))
    queue_manager.register(uid, task, kind="spam")

    acc_type = "🤖 Bot Token" if acc["type"] == "bot" else "👤 User Session"

    await update.message.reply_text(
        f"🚀 **BẮT ĐẦU SPAM**\n\n"
        f"━━━ **THÔNG TIN** ━━━\n"
        f"• Target: `{target}`\n"
        f"• Acc: {acc_type}\n"
        f"• Delay: {delay}s\n"
        f"• Ngôn: {len(ngon)} câu\n\n"
        f"━━━ **ĐANG CHẠY** ━━━\n"
        f"🟢 Spam/Tag: ON\n\n"
        f"💡 **Tắt:** `/off`\n"
        f"📊 Xem log: `/log`",
        parse_mode="Markdown"
    )


def _get_target(update, ctx):
    if update.message.reply_to_message:
        return update.message.reply_to_message.from_user.id
    if ctx.args:
        arg = ctx.args[0]
        if arg.startswith("@"):
            return arg
        try:
            return int(arg)
        except ValueError:
            return None
    return None


async def _tag_worker(ctx, uid, target, acc, ngon, delay):
    if acc["type"] == "bot":
        await _tag_via_bot(ctx, uid, target, acc, ngon, delay)
    else:
        await _tag_via_session(ctx, uid, target, acc, ngon, delay)


async def _tag_via_bot(ctx, uid, target, acc, ngon, delay):
    from telegram import Bot
    from telegram.error import TelegramError, RetryAfter

    bot = Bot(token=acc["token"])
    stats.start(uid, targets=1)

    try:
        while True:
            try:
                await rate_limiter.acquire()
                text = random.choice(ngon)

                if isinstance(target, str) and target.startswith("@"):
                    msg = f"{text} {target}"
                else:
                    msg = f"[{text}](tg://user?id={target})"

                await bot.send_message(target if not isinstance(target, str) else target.replace("@", ""),
                                        msg, parse_mode="Markdown")
                stats.inc_sent(uid)
                await asyncio.sleep(delay)

            except asyncio.CancelledError:
                break
            except RetryAfter as e:
                rate_limiter.handle_flood(e.retry_after)
                await asyncio.sleep(e.retry_after + 1)
            except TelegramError:
                stats.inc_failed(uid)
                await asyncio.sleep(delay)
    except asyncio.CancelledError:
        pass
    finally:
        stats.stop(uid)


async def _tag_via_session(ctx, uid, target, acc, ngon, delay):
    from telethon import TelegramClient
    from telethon.sessions import StringSession
    from telethon.errors import FloodWaitError

    client = TelegramClient(
        StringSession(acc["session"]),
        acc["api_id"], acc["api_hash"]
    )

    stats.start(uid, targets=1)

    try:
        await client.connect()
        if not await client.is_user_authorized():
            return

        try:
            entity = await client.get_entity(target)
        except Exception:
            return

        while True:
            try:
                await rate_limiter.acquire()
                text = random.choice(ngon)
                await client.send_message(entity, text)
                stats.inc_sent(uid)
                await asyncio.sleep(delay)

            except asyncio.CancelledError:
                break
            except FloodWaitError as e:
                rate_limiter.handle_flood(e.seconds)
                await asyncio.sleep(e.seconds + 1)
            except Exception:
                stats.inc_failed(uid)
                await asyncio.sleep(delay)
    except asyncio.CancelledError:
        pass
    finally:
        try:
            await client.disconnect()
        except Exception:
            pass