"""
/sua <uid> <cid> — Bỏ cam group (tắt /cam).
"""
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from core.queue_manager import queue_manager
from utils.autodelete import delete_cmd


async def sua_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if len(ctx.args) < 2:
        await update.message.reply_text(
            "📌 Dùng: `/sua <uid> <cid>`\n"
            "VD: `/sua 123456789 -1001234567890`",
            parse_mode="Markdown"
        )
        return

    try:
        target_uid = int(ctx.args[0])
        target_cid = int(ctx.args[1])
    except ValueError:
        await update.message.reply_text("❌ UID và CID phải là số.")
        return

    # Kiểm tra có cam không
    if not db.is_cam(uid, target_uid, target_cid):
        await update.message.reply_text(
            f"⚠️ Bạn chưa cam `{target_uid}` trong `{target_cid}`.",
            parse_mode="Markdown"
        )
        return

    db.remove_cam(uid, target_uid, target_cid)
    queue_manager.stop_user(uid)
    db.log(uid, "sua", f"{target_uid}@{target_cid}")

    await update.message.reply_text(
        f"🔊 **ĐÃ BỎ CAM**\n\n"
        f"• User: `{target_uid}`\n"
        f"• Group: `{target_cid}`\n\n"
        f"💡 Tin user gửi sẽ hiện bình thường.",
        parse_mode="Markdown"
    )