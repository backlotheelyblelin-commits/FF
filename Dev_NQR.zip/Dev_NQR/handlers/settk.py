"""/settk — Set default."""
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from utils.autodelete import delete_cmd


async def settk_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    if not ctx.args:
        await update.message.reply_text("Dùng: `/settk <id>`", parse_mode="Markdown")
        return

    try:
        acc_id = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID phải là số.")
        return

    acc = db.get_account(acc_id)
    if not acc or acc["owner_uid"] != uid:
        await update.message.reply_text("❌ Không tìm thấy acc.")
        return

    if acc["status"] != "active":
        await update.message.reply_text("⚠️ Acc chưa active.")
        return

    db.set_default(acc_id, uid)
    db.log(uid, "settk", str(acc_id))

    icon = "🤖" if acc["type"] == "bot" else "👤"
    await update.message.reply_text(
        f"⭐ **ĐÃ SET DEFAULT**\n\n"
        f"• Acc: {icon} `{acc['name']}` #{acc_id}\n"
        f"• Info: {acc.get('info', '?')}",
        parse_mode="Markdown"
    )