"""/deltk — Xóa acc."""
from telegram import Update
from telegram.ext import ContextTypes
from database.db import db
from utils.autodelete import delete_cmd


async def deltk_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)
    uid = update.effective_user.id

    # Chặn bot con
    if ctx.bot_data.get("is_botcon", False):
        await update.message.reply_text(
            "⛔ Bot con không xóa acc.\nVào bot chủ để dùng /deltk."
        )
        return

    if not ctx.args:
        await update.message.reply_text("Dùng: `/deltk <id>`", parse_mode="Markdown")
        return

    try:
        acc_id = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID phải là số.")
        return

    acc = db.get_account(acc_id)
    if not acc or acc["owner_uid"] != uid:
        await update.message.reply_text("❌ Không tìm thấy acc.")
        return

    db.delete_account(acc_id, owner_uid=uid)
    db.log(uid, "deltk", str(acc_id))

    await update.message.reply_text(
        f"🗑️ Đã xóa acc `{acc['name']}`.",
        parse_mode="Markdown"
    )