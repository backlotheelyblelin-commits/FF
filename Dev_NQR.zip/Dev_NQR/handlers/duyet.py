"""
/duyet <id> — Owner duyệt Bot Token chờ.
/tuclioi <id> — Từ chối.
"""
from telegram import Update
from telegram.ext import ContextTypes
from config import OWNER_ID
from database.db import db
from utils.permission import owner_only
from utils.autodelete import delete_cmd


@owner_only
async def duyet_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)

    if not ctx.args:
        # Hiện DS pending
        pending = db.get_accounts(status="pending")
        if not pending:
            await update.message.reply_text("✅ Không có acc chờ duyệt.")
            return

        lines = ["⏳ **ACC CHỜ DUYỆT**\n"]
        for a in pending:
            icon = "🤖" if a["type"] == "bot" else "👤"
            lines.append(f"{icon} `#{a['id']}` — user `{a['owner_uid']}` — `{a['name']}`")
        lines.append("\n👉 `/duyet <id>` để duyệt\n👉 `/tuclioi <id>` để từ chối")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
        return

    try:
        acc_id = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID phải là số.")
        return

    acc = db.get_account(acc_id)
    if not acc:
        await update.message.reply_text(f"❌ Không tìm thấy acc #{acc_id}")
        return

    db.update_account(acc_id, status="active")
    db.log(update.effective_user.id, "duyet", str(acc_id))

    await update.message.reply_text(f"✅ Đã duyệt acc #{acc_id}")

    try:
        await ctx.bot.send_message(
            acc["owner_uid"],
            f"✅ Acc `{acc['name']}` (#{acc_id}) đã được duyệt!",
            parse_mode="Markdown"
        )
    except Exception:
        pass


@owner_only
async def tuclioi_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await delete_cmd(update)

    if not ctx.args:
        await update.message.reply_text("Dùng: `/tuclioi <id>`", parse_mode="Markdown")
        return

    try:
        acc_id = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ ID phải là số.")
        return

    acc = db.get_account(acc_id)
    if not acc:
        await update.message.reply_text(f"❌ Không tìm thấy acc #{acc_id}")
        return

    db.update_account(acc_id, status="rejected")
    db.log(update.effective_user.id, "tuclioi", str(acc_id))

    await update.message.reply_text(f"🚫 Đã từ chối acc #{acc_id}")

    try:
        await ctx.bot.send_message(
            acc["owner_uid"],
            f"🚫 Acc `{acc['name']}` (#{acc_id}) đã bị từ chối.",
            parse_mode="Markdown"
        )
    except Exception:
        pass