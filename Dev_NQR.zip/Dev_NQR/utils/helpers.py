"""Helper functions."""
import re


def clean_otp(text):
    return re.sub(r"[^0-9]", "", text.strip())


def clean_phone(text):
    text = text.strip()
    plus = text.startswith("+")
    digits = re.sub(r"[^0-9]", "", text)
    return f"+{digits}" if plus else digits


def mask(text, show=6):
    if not text or len(text) <= show * 2:
        return "***"
    return f"{text[:show]}...{text[-show:]}"


def fmt_duration(seconds):
    h, r = divmod(int(seconds), 3600)
    m, s = divmod(r, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"