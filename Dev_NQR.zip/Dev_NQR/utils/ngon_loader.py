"""Load ngôn cho bot con."""
import json
from pathlib import Path

BOTS_DIR = Path(__file__).resolve().parent.parent / "data" / "bots"
NGON_BOT_CHU = Path(__file__).resolve().parent.parent / "data" / "ngon.json"


def get_ngon_for_botcon(acc_id, mode="1"):
    bot_dir = BOTS_DIR / f"bot_{acc_id}"
    settings_file = bot_dir / "settings.json"

    use_custom = False
    if settings_file.exists():
        try:
            settings = json.loads(settings_file.read_text(encoding="utf-8"))
            use_custom = settings.get("use_custom_ngon", False)
        except Exception:
            pass

    if use_custom:
        ngon_file = bot_dir / "ngon_user.json"
        if ngon_file.exists():
            try:
                ngon = json.loads(ngon_file.read_text(encoding="utf-8"))
                all_lines = []
                for arr in ngon.get(mode, {}).values():
                    all_lines.extend(arr)
                if all_lines:
                    return all_lines
            except Exception:
                pass

    if NGON_BOT_CHU.exists():
        try:
            ngon = json.loads(NGON_BOT_CHU.read_text(encoding="utf-8"))
            all_lines = []
            for arr in ngon.get(mode, {}).values():
                all_lines.extend(arr)
            return all_lines
        except Exception:
            pass

    return []