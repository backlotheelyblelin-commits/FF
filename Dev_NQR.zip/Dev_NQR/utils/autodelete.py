"""Xóa tin lệnh user."""
import asyncio
from database.db import db

_clients_cache: dict[int, object] = {}
_lock = asyncio.Lock()


async def _get_client(uid):
    async with _lock:
        if uid in _clients_cache:
            client = _clients_cache[uid]
            try:
                if await client.is_user_authorized():
                    return client
            except Exception:
                pass

        acc = db.get_default_account(uid)
        if not acc or acc["type"] != "user" or not acc.get("session"):
            return None

        try:
            from telethon import TelegramClient
            from telethon.sessions import StringSession

            client = TelegramClient(
                StringSession(acc["session"]),
                acc["api_id"], acc["api_hash"]
            )
            await client.connect()

            if not await client.is_user_authorized():
                await client.disconnect()
                return None

            _clients_cache[uid] = client
            return client
        except Exception:
            return None


async def delete_cmd(update):
    if not update.message:
        return False

    uid = update.effective_user.id
    chat_id = update.effective_chat.id
    msg_id = update.message.message_id

    client = await _get_client(uid)
    if client:
        try:
            await client.delete_messages(chat_id, [msg_id])
            return True
        except Exception:
            pass

    try:
        await update.message.delete()
        return True
    except Exception:
        return False


async def cleanup_clients():
    for c in list(_clients_cache.values()):
        try:
            await c.disconnect()
        except Exception:
            pass
    _clients_cache.clear()