"""Build menu theo cấp user + context bot."""
from utils.keyboards import btn
from config import is_owner, is_admin


TEXT_USER = """📖 **LỆNH USER**

🔹 Cơ bản:
`/start` `/mn` `/help` `/id` `/ping` `/lang`

🔹 Voice:
`/voice` `/giong` `/thay`

🔹 Spam:
`/tag` `/tag2` `/call` `/treongon`
`/set` `/setcall` `/off`

🔹 Thống kê:
`/log` `/status`

🔹 Mod:
`/im` `/noi` `/cam` `/sua`
`/sc` `/anti` `/clear`
"""

TEXT_ADMIN = """

👮 **LỆNH ADMIN**
`/add` `/add2` `/addtreo`
`/listngon` `/delngon` `/clearngon`
`/duyet` `/tuclioi` `/alltk`
`/globalstatus` `/admin`
"""

TEXT_OWNER = """

👑 **LỆNH OWNER**
`/sl` `/setadmin` `/deladmin` `/listadmin` `/setquyen`
`/broadcast` `/bctest` `/bcstat`
`/backup` `/restore` `/dbcheck` `/dblist` `/dbclean`
`/monitor` `/offall` `/logall`
`/blacklist` `/whitelist` `/bantk`
"""


def get_start_text(uid, is_botcon=False, bot_name=None, emoji=None, custom_text=None, footer=None):
    if is_botcon:
        name = bot_name or "My Bot"
        icon = emoji or "🤖"
        text = custom_text or "Bot đã sẵn sàng!"
        start = f"{icon} **{name}**\n{text}\n"
        if footer:
            start += f"_{footer}_\n"
        start += "\n" + TEXT_USER
        return start

    start = "🏠 **MENU CHÍNH**\n"
    start += TEXT_USER
    if is_admin(uid):
        start += TEXT_ADMIN
    if is_owner(uid):
        start += TEXT_OWNER
    return start


def get_menu_rows(uid, is_botcon=False):
    if is_botcon:
        return [
            [btn("📋 Xem ALL lệnh", "help:all")],
            [btn("📖 Lệnh chi tiết", "help:main")],
            [btn("📊 Trạng thái", "status:my")],
            [btn("🌐 Ngôn ngữ", "lang:menu")],
            [btn("⚙️ Sửa bot này", "bot:config")],
        ]

    rows = [
        [btn("📖 Xem chi tiết lệnh", "help:main")],
        [btn("👤 Tài khoản", "mytk:list")],
        [btn("📊 Trạng thái", "status:my")],
        [btn("🌐 Ngôn ngữ", "lang:menu")],
        [btn("🤖 Bot con của tôi", "mybot:list")],
        [btn("⚙️ Settings bot con", "mybot:config")],
    ]
    if is_admin(uid):
        rows.append([btn("👮 Admin Panel", "admin:panel")])
    if is_owner(uid):
        rows.append([btn("⚙️ Settings bot chủ", "sl:main")])
    return rows


def get_help_rows(uid, is_botcon=False):
    if is_botcon:
        return [
            [btn("📖 Lệnh User", "help:user")],
            [btn("⚙️ Cài đặt bot", "bot:config")],
            [btn("🔙 Quay lại", "main:menu")],
        ]
    rows = [[btn("📖 Lệnh User", "help:user")]]
    if is_admin(uid):
        rows.append([btn("👮 Lệnh Admin", "help:admin")])
    if is_owner(uid):
        rows.append([btn("👑 Lệnh Owner", "help:owner")])
    rows.append([btn("⚙️ Settings bot con", "mybot:config")])
    rows.append([btn("🔙 Quay lại", "main:menu")])
    return rows