"""Cache Telethon client."""
import asyncio
from database.db import db

_clients: dict[int, object] = {}
_lock = asyncio.Lock()


async def get_client(uid):
    async with _lock:
        if uid in _clients:
            client = _clients[uid]
            try:
                if await client.is_user_authorized():
                    return client
            except Exception:
                pass

        acc = db.get_default_account(uid)
        if not acc or acc["type"] != "user" or not acc.get("session"):
            return None

        try:
            from telethon import TelegramClient
            from telethon.sessions import StringSession

            client = TelegramClient(
                StringSession(acc["session"]),
                acc["api_id"], acc["api_hash"]
            )
            await client.connect()

            if not await client.is_user_authorized():
                await client.disconnect()
                return None

            _clients[uid] = client
            return client
        except Exception:
            return None


async def close_client(uid):
    async with _lock:
        if uid in _clients:
            try:
                await _clients[uid].disconnect()
            except Exception:
                pass
            _clients.pop(uid, None)


async def close_all():
    for uid in list(_clients.keys()):
        await close_client(uid)