"""Decorator check quyền."""
from functools import wraps
from config import is_owner, is_admin


def owner_only(func):
    @wraps(func)
    async def wrapper(update, ctx, *a, **kw):
        if not is_owner(update.effective_user.id):
            await update.message.reply_text("👑 Chỉ chủ bot.")
            return
        return await func(update, ctx, *a, **kw)
    return wrapper


def admin_only(func):
    @wraps(func)
    async def wrapper(update, ctx, *a, **kw):
        if not is_admin(update.effective_user.id):
            await update.message.reply_text("👮 Chỉ admin bot.")
            return
        return await func(update, ctx, *a, **kw)
    return wrapper


def can_target(actor, target):
    if actor == target:
        return False, "❌ Không thể target chính mình."
    if is_owner(actor):
        return True, ""
    if is_admin(actor):
        if is_owner(target):
            return False, "⛔ Không thể target chủ bot."
        return True, ""
    if is_owner(target):
        return False, "⛔ Không thể target chủ bot."
    if is_admin(target):
        return False, "⛔ Không thể target admin."
    return True, ""