"""Check bot là admin group."""
from telegram import Bot


async def check_bot_admin(bot_token, group_id):
    try:
        bot = Bot(bot_token)
        me = await bot.get_me()
        member = await bot.get_chat_member(group_id, me.id)

        status = member.status
        if status not in ("administrator", "creator"):
            return False, "Bot không phải admin group"

        if status == "administrator":
            if not getattr(member, "can_delete_messages", False):
                return False, "Bot không có quyền Xóa tin nhắn"

        return True, ""
    except Exception as e:
        return False, f"Lỗi: {e}"