"""Xác minh user tham gia CHAT + KÊNH."""
from telegram import Bot
from telegram.error import TelegramError


VERIFY_CHATS = [
    {
        "id": -1004431538829,
        "name": "CHAT",
        "type": "group",
        "url": "https://t.me/CHAT_NB_BP_VN",
        "icon": "💬",
    },
    {
        "id": -1004305476637,
        "name": "KÊNH",
        "type": "channel",
        "url": "https://t.me/NB_BP_VN",
        "icon": "📢",
    },
]


async def check_user_joined(bot, uid):
    missing = []
    for chat in VERIFY_CHATS:
        try:
            member = await bot.get_chat_member(chat["id"], uid)
            status = member.status
            if status in ("left", "kicked"):
                missing.append(chat)
            elif status == "restricted" and not getattr(member, "is_member", False):
                missing.append(chat)
        except TelegramError as e:
            print(f"⚠️ Lỗi check {chat['name']}: {e}")
            missing.append(chat)
    return len(missing) == 0, missing