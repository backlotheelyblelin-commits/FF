"""Helper tạo nút."""
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def btn(text, data):
    return InlineKeyboardButton(text, callback_data=data)


def back_button(data="main:menu"):
    return InlineKeyboardButton("🔙 Quay lại", callback_data=data)


def build_menu(*rows):
    return InlineKeyboardMarkup(list(rows))