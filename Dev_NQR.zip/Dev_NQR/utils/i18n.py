"""Đa ngôn ngữ Việt/Anh."""
from database.db import db

DEFAULT_LANG = "vi"

TRANSLATIONS = {
    "vi": {
        "menu_title": "🏠 MENU CHÍNH\n\nChọn:",
        "only_owner": "👑 Chỉ chủ bot.",
        "only_admin": "👮 Chỉ admin bot.",
    },
    "en": {
        "menu_title": "🏠 MAIN MENU\n\nChoose:",
        "only_owner": "👑 Owner only.",
        "only_admin": "👮 Admin only.",
    },
}


def get_lang(uid: int) -> str:
    try:
        lang = db.get_user_setting(uid, "lang", DEFAULT_LANG)
        return lang if lang in TRANSLATIONS else DEFAULT_LANG
    except Exception:
        return DEFAULT_LANG


def set_lang(uid: int, lang: str) -> bool:
    if lang not in TRANSLATIONS:
        return False
    try:
        db.set_user_setting(uid, "lang", lang)
        return True
    except Exception:
        return False


def t(uid: int, key: str, **kwargs) -> str:
    lang = get_lang(uid)
    text = TRANSLATIONS.get(lang, TRANSLATIONS[DEFAULT_LANG]).get(key, key)
    if kwargs:
        try:
            return text.format(**kwargs)
        except Exception:
            return text
    return text