"""Auto backup + cleanup."""
import shutil
from datetime import datetime, timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "data" / "bot.db"
BACKUP_DIR = BASE_DIR / "data" / "backups"
BACKUP_DIR.mkdir(parents=True, exist_ok=True)


async def auto_backup(ctx):
    """Auto backup mỗi ngày."""
    try:
        if not DB_PATH.exists():
            return

        ts = datetime.now().strftime("%Y%m%d")
        backup_file = BACKUP_DIR / f"auto_{ts}.db"

        if backup_file.exists():
            return

        shutil.copy2(DB_PATH, backup_file)

        cutoff = (datetime.now() - timedelta(days=7)).timestamp()
        for f in BACKUP_DIR.glob("auto_*.db"):
            if f.stat().st_mtime < cutoff:
                f.unlink()

        print(f"✅ Auto backup: {backup_file.name}")
    except Exception as e:
        print(f"❌ Auto backup lỗi: {e}")


async def auto_cleanup(ctx):
    """Auto cleanup log."""
    try:
        log_file = BASE_DIR / "logs" / "bot.log"
        if log_file.exists() and log_file.stat().st_size > 10 * 1024 * 1024:
            log_file.write_text("")
    except Exception:
        pass